﻿// Copyright (c) 2001-2021 Aspose Pty Ltd. All Rights Reserved.
// This file is part of Aspose.Words. The source code in this file
// is only intended as a supplement to the documentation, and is provided
// "as is", without warranty of any kind, either expressed or implied.
//////////////////////////////////////////////////////////////////////////
#include "ExThemes.h"

using namespace Aspose::Words;
using namespace Aspose::Words::Themes;
namespace ApiExamples { namespace gtest_test {

class ExThemes : public ::testing::Test
{
protected:
    static System::SharedPtr<::ApiExamples::ExThemes> s_instance;

    void SetUp() override
    {
        s_instance->SetUp();
    };

    static void SetUpTestCase()
    {
        s_instance = System::MakeObject<::ApiExamples::ExThemes>();
        s_instance->OneTimeSetUp();
    };

    static void TearDownTestCase()
    {
        s_instance->OneTimeTearDown();
        s_instance = nullptr;
    };
};

System::SharedPtr<::ApiExamples::ExThemes> ExThemes::s_instance;

TEST_F(ExThemes, CustomColorsAndFonts)
{
    s_instance->CustomColorsAndFonts();
}

}} // namespace ApiExamples::gtest_test
