var classpdftron_1_1_p_d_f_1_1_annots_1_1_sound =
[
    [ "Icon", "classpdftron_1_1_p_d_f_1_1_annots_1_1_sound.html#af2912d2985c138992b485ef769086f9e", [
      [ "e_Speaker", "classpdftron_1_1_p_d_f_1_1_annots_1_1_sound.html#af2912d2985c138992b485ef769086f9eac99799f33012977b04a180309fb76748", null ],
      [ "e_Mic", "classpdftron_1_1_p_d_f_1_1_annots_1_1_sound.html#af2912d2985c138992b485ef769086f9eac0012a53e65bdac62ab2bab74b491121", null ],
      [ "e_Unknown", "classpdftron_1_1_p_d_f_1_1_annots_1_1_sound.html#af2912d2985c138992b485ef769086f9eab7277b3a21e22a212197ad637a3aaa5b", null ]
    ] ],
    [ "Sound", "classpdftron_1_1_p_d_f_1_1_annots_1_1_sound.html#abc4f22c9daa8d870369543a9b37ecf28", null ],
    [ "Sound", "classpdftron_1_1_p_d_f_1_1_annots_1_1_sound.html#a62daeccff52dd28b26bdb1140b916da8", null ],
    [ "Create", "classpdftron_1_1_p_d_f_1_1_annots_1_1_sound.html#a746bd7a4b0a37c88f704d1bdeb3c8204", null ],
    [ "Create", "classpdftron_1_1_p_d_f_1_1_annots_1_1_sound.html#a2e38d3cdf634ffbaeaded23150e4dad6", null ],
    [ "CreateWithData", "classpdftron_1_1_p_d_f_1_1_annots_1_1_sound.html#ae8d0d916cb5013539ebe69d72b77e4f7", null ],
    [ "GetIcon", "classpdftron_1_1_p_d_f_1_1_annots_1_1_sound.html#a1b5da083245be5ee0d46253362cb183e", null ],
    [ "GetIconName", "classpdftron_1_1_p_d_f_1_1_annots_1_1_sound.html#afe045ac5c24a0911f484b53db752c0ec", null ],
    [ "GetSoundStream", "classpdftron_1_1_p_d_f_1_1_annots_1_1_sound.html#a2c99a1be69c516f57a81a3992603307f", null ],
    [ "SetIcon", "classpdftron_1_1_p_d_f_1_1_annots_1_1_sound.html#a5f76130bf93f713d3337f2e68efba789", null ],
    [ "SetIcon", "classpdftron_1_1_p_d_f_1_1_annots_1_1_sound.html#a77ae7aec57738264c92bf4ffe70f425c", null ],
    [ "SetSoundStream", "classpdftron_1_1_p_d_f_1_1_annots_1_1_sound.html#ab80e2dfbc5a2ba098c86456a43a4a4db", null ]
];