var classpdftron_1_1_p_d_f_1_1_annots_1_1_popup =
[
    [ "Popup", "classpdftron_1_1_p_d_f_1_1_annots_1_1_popup.html#a82dc079857bd7a25c9f58eb568afce71", null ],
    [ "Popup", "classpdftron_1_1_p_d_f_1_1_annots_1_1_popup.html#ad7a3233c86a0b858ccb0b9e42c33501f", null ],
    [ "Create", "classpdftron_1_1_p_d_f_1_1_annots_1_1_popup.html#a462bca7d435443778729c1adbe17743d", null ],
    [ "GetParent", "classpdftron_1_1_p_d_f_1_1_annots_1_1_popup.html#a2d48aee09e25007bbdf1fa16b53a418b", null ],
    [ "IsOpen", "classpdftron_1_1_p_d_f_1_1_annots_1_1_popup.html#a9f0b5f0ab86f096493cdbeecf6445673", null ],
    [ "SetOpen", "classpdftron_1_1_p_d_f_1_1_annots_1_1_popup.html#a35d91d5df369138d9eb30d604dac238d", null ],
    [ "SetParent", "classpdftron_1_1_p_d_f_1_1_annots_1_1_popup.html#a60c54e7afe234e7c6fde5a489b289d45", null ]
];