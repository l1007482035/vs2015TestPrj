var classpdftron_1_1_p_d_f_1_1_annots_1_1_link =
[
    [ "HighlightingMode", "classpdftron_1_1_p_d_f_1_1_annots_1_1_link.html#a1c3ea9adecc87034c50775a93f740d64", [
      [ "e_none", "classpdftron_1_1_p_d_f_1_1_annots_1_1_link.html#a1c3ea9adecc87034c50775a93f740d64ad6f1f30add6e8372c36441f1a5b5a15d", null ],
      [ "e_invert", "classpdftron_1_1_p_d_f_1_1_annots_1_1_link.html#a1c3ea9adecc87034c50775a93f740d64a810ad4c97c9c8cc9b57e8046fe339845", null ],
      [ "e_outline", "classpdftron_1_1_p_d_f_1_1_annots_1_1_link.html#a1c3ea9adecc87034c50775a93f740d64a66b08f39b0a4910c984da383b59bd778", null ],
      [ "e_push", "classpdftron_1_1_p_d_f_1_1_annots_1_1_link.html#a1c3ea9adecc87034c50775a93f740d64a73fae0e755e8dd3534d948b44e5fac29", null ]
    ] ],
    [ "Link", "classpdftron_1_1_p_d_f_1_1_annots_1_1_link.html#a9da6a2afbc5924f9d59632a60de2723e", null ],
    [ "Link", "classpdftron_1_1_p_d_f_1_1_annots_1_1_link.html#af0fb776e57fc92ed1408d684ecb96df0", null ],
    [ "Create", "classpdftron_1_1_p_d_f_1_1_annots_1_1_link.html#a21c6afcc5269ab61f68ffbadc4ebafc5", null ],
    [ "Create", "classpdftron_1_1_p_d_f_1_1_annots_1_1_link.html#a9402bbe80ca35d77927ab0a2ca4ff42f", null ],
    [ "GetAction", "classpdftron_1_1_p_d_f_1_1_annots_1_1_link.html#a4c58a3935d3418a831ae10b2a496188d", null ],
    [ "GetHighlightingMode", "classpdftron_1_1_p_d_f_1_1_annots_1_1_link.html#a12a9c337e263fdb7a3aa7c6343318ddf", null ],
    [ "GetNormalizedUrl", "classpdftron_1_1_p_d_f_1_1_annots_1_1_link.html#a14ac07421e9fc71f8322242d291f5849", null ],
    [ "GetQuadPoint", "classpdftron_1_1_p_d_f_1_1_annots_1_1_link.html#a2d2ef44428009b184eafdd661eb77719", null ],
    [ "GetQuadPointCount", "classpdftron_1_1_p_d_f_1_1_annots_1_1_link.html#abdbad111b67042d746bb69d74fde2a5b", null ],
    [ "RemoveAction", "classpdftron_1_1_p_d_f_1_1_annots_1_1_link.html#a450fa5ac650632225aec1e4be87f0c33", null ],
    [ "SetAction", "classpdftron_1_1_p_d_f_1_1_annots_1_1_link.html#a6cb029724a183bc5ab53f57fd44e17ca", null ],
    [ "SetHighlightingMode", "classpdftron_1_1_p_d_f_1_1_annots_1_1_link.html#a32c7e5c63193936a02ada0b2cc1a9fba", null ],
    [ "SetQuadPoint", "classpdftron_1_1_p_d_f_1_1_annots_1_1_link.html#a11308b682d8f7b70b5bb105e398ccfb3", null ]
];