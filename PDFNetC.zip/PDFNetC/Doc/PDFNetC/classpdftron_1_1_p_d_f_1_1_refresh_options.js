var classpdftron_1_1_p_d_f_1_1_refresh_options =
[
    [ "RefreshOptions", "classpdftron_1_1_p_d_f_1_1_refresh_options.html#adcf1a88cfa543f5601b122f4dc449ce3", null ],
    [ "~RefreshOptions", "classpdftron_1_1_p_d_f_1_1_refresh_options.html#a234e7f659f51233f7cb7ca3d2aa07c2a", null ],
    [ "GetDrawBackgroundOnly", "classpdftron_1_1_p_d_f_1_1_refresh_options.html#a71ad999b3f35f0d70c6882a4aa6e247a", null ],
    [ "GetRefreshExisting", "classpdftron_1_1_p_d_f_1_1_refresh_options.html#aabac0406cb217c5a6e3ec23e485aa89a", null ],
    [ "GetUseNonStandardRotation", "classpdftron_1_1_p_d_f_1_1_refresh_options.html#aaeafaee22458375fa23041ca73f1c6de", null ],
    [ "GetUseRoundedCorners", "classpdftron_1_1_p_d_f_1_1_refresh_options.html#a19cd99c651901994bbebe8587dd1dccf", null ],
    [ "SetDrawBackgroundOnly", "classpdftron_1_1_p_d_f_1_1_refresh_options.html#ab3a79c32360863417e16c39f88a6a68f", null ],
    [ "SetRefreshExisting", "classpdftron_1_1_p_d_f_1_1_refresh_options.html#a971bd88cf10f8f92e4254e399b40d6f4", null ],
    [ "SetUseNonStandardRotation", "classpdftron_1_1_p_d_f_1_1_refresh_options.html#a9676e4a239be8a789c0c4e701c2255a9", null ],
    [ "SetUseRoundedCorners", "classpdftron_1_1_p_d_f_1_1_refresh_options.html#ad2a3876b470e4348b5a431958d5275ea", null ]
];