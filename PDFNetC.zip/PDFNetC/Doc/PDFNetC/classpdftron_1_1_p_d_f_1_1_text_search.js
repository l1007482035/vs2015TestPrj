var classpdftron_1_1_p_d_f_1_1_text_search =
[
    [ "Mode", "classpdftron_1_1_p_d_f_1_1_text_search.html#aa39534eb7777537d3a1ec8c50afe825f", null ],
    [ "TextSearchModes", "classpdftron_1_1_p_d_f_1_1_text_search.html#ad476cf37ffe65353b616be3e73c67647", [
      [ "e_reg_expression", "classpdftron_1_1_p_d_f_1_1_text_search.html#ad476cf37ffe65353b616be3e73c67647a72368e3ce351c04390833c4c21ca856d", null ],
      [ "e_case_sensitive", "classpdftron_1_1_p_d_f_1_1_text_search.html#ad476cf37ffe65353b616be3e73c67647ac96522e35e6c7e24cb7b9567b6243424", null ],
      [ "e_whole_word", "classpdftron_1_1_p_d_f_1_1_text_search.html#ad476cf37ffe65353b616be3e73c67647a13f4bbaeab7d4d752da135ff8139afef", null ],
      [ "e_search_up", "classpdftron_1_1_p_d_f_1_1_text_search.html#ad476cf37ffe65353b616be3e73c67647aa2e986648f6bae7c6d1fa062d59cb33d", null ],
      [ "e_page_stop", "classpdftron_1_1_p_d_f_1_1_text_search.html#ad476cf37ffe65353b616be3e73c67647ab613a105dc015d8a32b4f610b6cef797", null ],
      [ "e_highlight", "classpdftron_1_1_p_d_f_1_1_text_search.html#ad476cf37ffe65353b616be3e73c67647ae1fef6d5132a70532a8d54e97242dea8", null ],
      [ "e_ambient_string", "classpdftron_1_1_p_d_f_1_1_text_search.html#ad476cf37ffe65353b616be3e73c67647aa023ab3ef825bd11cf44dc1ecaeb4dbf", null ],
      [ "e_raw_text_search", "classpdftron_1_1_p_d_f_1_1_text_search.html#ad476cf37ffe65353b616be3e73c67647a67447098aed5c4f7acf974d9e812bed5", null ]
    ] ],
    [ "TextSearch", "classpdftron_1_1_p_d_f_1_1_text_search.html#a5b11d6ab6b2125f068145318264d42f9", null ],
    [ "~TextSearch", "classpdftron_1_1_p_d_f_1_1_text_search.html#a084bc62a8149d3eb0352d6f129919a14", null ],
    [ "Begin", "classpdftron_1_1_p_d_f_1_1_text_search.html#a5b4f6ece6bd072bafd62902a2f78e711", null ],
    [ "Destroy", "classpdftron_1_1_p_d_f_1_1_text_search.html#a495875f46a405bf9c825c5e5c62c67f1", null ],
    [ "GetCurrentPage", "classpdftron_1_1_p_d_f_1_1_text_search.html#a5900102f178c5c0209e73cc04352acd6", null ],
    [ "GetMode", "classpdftron_1_1_p_d_f_1_1_text_search.html#a303854a34290cc01fbeec5b39faa6999", null ],
    [ "Run", "classpdftron_1_1_p_d_f_1_1_text_search.html#a73386fe6da9a72511a13a551a2936b7d", null ],
    [ "SetMode", "classpdftron_1_1_p_d_f_1_1_text_search.html#a6cd155507e70b0e71ef90d700449a40d", null ],
    [ "SetOCGContext", "classpdftron_1_1_p_d_f_1_1_text_search.html#a80e2d930efb082b181c924b411508a19", null ],
    [ "SetPattern", "classpdftron_1_1_p_d_f_1_1_text_search.html#a7ffceb36fe2f92c8a5110efc836e4590", null ],
    [ "SetRightToLeftLanguage", "classpdftron_1_1_p_d_f_1_1_text_search.html#a5f8913ea10409584d749d2429a11d252", null ]
];