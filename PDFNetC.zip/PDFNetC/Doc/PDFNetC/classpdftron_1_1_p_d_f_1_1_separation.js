var classpdftron_1_1_p_d_f_1_1_separation =
[
    [ "Separation", "classpdftron_1_1_p_d_f_1_1_separation.html#ae976ac818f0f6f8d9929e9c90dba8a79", null ],
    [ "~Separation", "classpdftron_1_1_p_d_f_1_1_separation.html#aabfd8fdae751877eed58c0d50840dadb", null ],
    [ "Separation", "classpdftron_1_1_p_d_f_1_1_separation.html#a0e4a87134c26e22ea61df40e8df947b4", null ],
    [ "C", "classpdftron_1_1_p_d_f_1_1_separation.html#a773f99f1690079352dc253c4171d4480", null ],
    [ "GetData", "classpdftron_1_1_p_d_f_1_1_separation.html#a1de5e7d3606d2f9e819c96aec4bf46f4", null ],
    [ "GetDataSize", "classpdftron_1_1_p_d_f_1_1_separation.html#ae89e3b645772b9504fb79e6663dbe596", null ],
    [ "GetSeparationName", "classpdftron_1_1_p_d_f_1_1_separation.html#afbd492df87d306224aede8a1e9201927", null ],
    [ "K", "classpdftron_1_1_p_d_f_1_1_separation.html#a95916d32c0f0289bda5f354ed278414c", null ],
    [ "M", "classpdftron_1_1_p_d_f_1_1_separation.html#a4efb3123155d36446405220f43850fff", null ],
    [ "operator=", "classpdftron_1_1_p_d_f_1_1_separation.html#a443b57e339f8807634a7937f19909437", null ],
    [ "Y", "classpdftron_1_1_p_d_f_1_1_separation.html#ab61e56b49861da08d431cd8e6eb1153c", null ],
    [ "m_separation_name", "classpdftron_1_1_p_d_f_1_1_separation.html#ad2a09a0632c587224c961df6198489b6", null ]
];