var classpdftron_1_1_p_d_f_1_1_search_result =
[
    [ "GetAmbientString", "classpdftron_1_1_p_d_f_1_1_search_result.html#a81e62476fbe8988d2d51a833f95c508c", null ],
    [ "GetHighlights", "classpdftron_1_1_p_d_f_1_1_search_result.html#ae62aa00a01f139fea234032dd851253c", null ],
    [ "GetMatch", "classpdftron_1_1_p_d_f_1_1_search_result.html#adcdbb77f3e3cecbef4bfb326396db91c", null ],
    [ "GetPageNumber", "classpdftron_1_1_p_d_f_1_1_search_result.html#a2e481ba5a2e4d4f1cb76e63cb87c0ddc", null ],
    [ "IsDocEnd", "classpdftron_1_1_p_d_f_1_1_search_result.html#add114eea2253a169917a24a294a8339b", null ],
    [ "IsFound", "classpdftron_1_1_p_d_f_1_1_search_result.html#aeaf6063be06d54b30d9245dda11993b9", null ],
    [ "IsPageEnd", "classpdftron_1_1_p_d_f_1_1_search_result.html#a5897dad4d971d73adaf93fe44f1ef373", null ],
    [ "operator bool", "classpdftron_1_1_p_d_f_1_1_search_result.html#a05a616d8319ae2485fd2ba41d567d35f", null ]
];