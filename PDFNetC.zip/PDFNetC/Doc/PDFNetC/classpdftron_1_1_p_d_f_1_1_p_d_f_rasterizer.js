var classpdftron_1_1_p_d_f_1_1_p_d_f_rasterizer =
[
    [ "ErrorReportProc", "classpdftron_1_1_p_d_f_1_1_p_d_f_rasterizer.html#ac21346f017c531507002aaefe9ea06ad", null ],
    [ "ColorPostProcessMode", "classpdftron_1_1_p_d_f_1_1_p_d_f_rasterizer.html#a3640c40d0c167e2e18d7234bbedd51d3", [
      [ "e_postprocess_none", "classpdftron_1_1_p_d_f_1_1_p_d_f_rasterizer.html#a3640c40d0c167e2e18d7234bbedd51d3a6c91e65f9609bdd7827470bcdc3ee356", null ],
      [ "e_postprocess_invert", "classpdftron_1_1_p_d_f_1_1_p_d_f_rasterizer.html#a3640c40d0c167e2e18d7234bbedd51d3a171977b78e1e8c8d4fa0317c99da53a8", null ],
      [ "e_postprocess_gradient_map", "classpdftron_1_1_p_d_f_1_1_p_d_f_rasterizer.html#a3640c40d0c167e2e18d7234bbedd51d3aaa7e335f141b62d447f06e5558449a36", null ],
      [ "e_postprocess_night_mode", "classpdftron_1_1_p_d_f_1_1_p_d_f_rasterizer.html#a3640c40d0c167e2e18d7234bbedd51d3a4d3cc5bd707aa071feb3c25cb9e9b6f3", null ]
    ] ],
    [ "OverprintPreviewMode", "classpdftron_1_1_p_d_f_1_1_p_d_f_rasterizer.html#ab33109af54e92e385e8d3a1a66bc4c0d", [
      [ "e_op_off", "classpdftron_1_1_p_d_f_1_1_p_d_f_rasterizer.html#ab33109af54e92e385e8d3a1a66bc4c0da642c97e26aa418fc9c18cded0dfdaaa8", null ],
      [ "e_op_on", "classpdftron_1_1_p_d_f_1_1_p_d_f_rasterizer.html#ab33109af54e92e385e8d3a1a66bc4c0da8691626b7b2f6cfb10012a7f1a17b992", null ],
      [ "e_op_pdfx_on", "classpdftron_1_1_p_d_f_1_1_p_d_f_rasterizer.html#ab33109af54e92e385e8d3a1a66bc4c0da2e07b72044ab3772c6683168eaf25f3a", null ]
    ] ],
    [ "Type", "classpdftron_1_1_p_d_f_1_1_p_d_f_rasterizer.html#a5fbad809317dc7830f02a623ef9343a5", [
      [ "e_BuiltIn", "classpdftron_1_1_p_d_f_1_1_p_d_f_rasterizer.html#a5fbad809317dc7830f02a623ef9343a5ab9ddc3dc2111154179ee046008886500", null ],
      [ "e_GDIPlus", "classpdftron_1_1_p_d_f_1_1_p_d_f_rasterizer.html#a5fbad809317dc7830f02a623ef9343a5a77c8eb50b5d0b780c198c691f8e7df2a", null ]
    ] ],
    [ "PDFRasterizer", "classpdftron_1_1_p_d_f_1_1_p_d_f_rasterizer.html#ab7d70684e13a53d8944bcbe0ba02fabc", null ],
    [ "~PDFRasterizer", "classpdftron_1_1_p_d_f_1_1_p_d_f_rasterizer.html#a08ded36e9cef99682e453e903071d376", null ],
    [ "Destroy", "classpdftron_1_1_p_d_f_1_1_p_d_f_rasterizer.html#ab313e89fa461b25cc20b37e273db9e7c", null ],
    [ "GetColorPostProcessMode", "classpdftron_1_1_p_d_f_1_1_p_d_f_rasterizer.html#afb414b1d163b42a35956908efae7c0d4", null ],
    [ "GetRasterizerType", "classpdftron_1_1_p_d_f_1_1_p_d_f_rasterizer.html#ac0dd59037898685caaae512b2a414362", null ],
    [ "Rasterize", "classpdftron_1_1_p_d_f_1_1_p_d_f_rasterizer.html#aa4a7ac224f1797be10cb951d06d02739", null ],
    [ "Rasterize", "classpdftron_1_1_p_d_f_1_1_p_d_f_rasterizer.html#a0236578d503e0d9c7e6d8fe0912e38d8", null ],
    [ "Rasterize", "classpdftron_1_1_p_d_f_1_1_p_d_f_rasterizer.html#ade26b86742a2d15bdd1bd7de3ca93010", null ],
    [ "RasterizeSeparations", "classpdftron_1_1_p_d_f_1_1_p_d_f_rasterizer.html#a8865b5cb6534625cd88eee6193df5ecc", null ],
    [ "SetAntiAliasing", "classpdftron_1_1_p_d_f_1_1_p_d_f_rasterizer.html#a90e170d729136603c7fca4a241c51590", null ],
    [ "SetCaching", "classpdftron_1_1_p_d_f_1_1_p_d_f_rasterizer.html#a7909f693747e771aefe118d03dcdc835", null ],
    [ "SetColorPostProcessMode", "classpdftron_1_1_p_d_f_1_1_p_d_f_rasterizer.html#a088f8c5b410a398a48b66a3d1394eaf5", null ],
    [ "SetDrawAnnotations", "classpdftron_1_1_p_d_f_1_1_p_d_f_rasterizer.html#a65625c4d3c16234b5cdccd2dd64cfe8a", null ],
    [ "SetErrorReportProc", "classpdftron_1_1_p_d_f_1_1_p_d_f_rasterizer.html#adcf4da6d33ee3a016cd9d45cdb5a25c0", null ],
    [ "SetGamma", "classpdftron_1_1_p_d_f_1_1_p_d_f_rasterizer.html#a2d8eaa2d9cac02d30a08306815c868ce", null ],
    [ "SetHighlightFields", "classpdftron_1_1_p_d_f_1_1_p_d_f_rasterizer.html#aae2b875caee9d598ca1e6fa26ba20b89", null ],
    [ "SetImageSmoothing", "classpdftron_1_1_p_d_f_1_1_p_d_f_rasterizer.html#aefb9e2f35fbc8bdfcfba901efa25e32e", null ],
    [ "SetOCGContext", "classpdftron_1_1_p_d_f_1_1_p_d_f_rasterizer.html#a406dba251be170ac721000c30c3c0f39", null ],
    [ "SetOverprint", "classpdftron_1_1_p_d_f_1_1_p_d_f_rasterizer.html#aea3de4db3b1d9b99d7018612039fbab2", null ],
    [ "SetPathHinting", "classpdftron_1_1_p_d_f_1_1_p_d_f_rasterizer.html#a175df7c7994fb4578bd18238df739dc6", null ],
    [ "SetPrintMode", "classpdftron_1_1_p_d_f_1_1_p_d_f_rasterizer.html#a944852492b457b02f0634019bb5e6a43", null ],
    [ "SetRasterizerType", "classpdftron_1_1_p_d_f_1_1_p_d_f_rasterizer.html#a2bbc06454514b30f3226e5f290e001ae", null ],
    [ "SetThinLineAdjustment", "classpdftron_1_1_p_d_f_1_1_p_d_f_rasterizer.html#a9abdc7ad2b96dfcad2135a0c75aed96a", null ],
    [ "UpdateBuffer", "classpdftron_1_1_p_d_f_1_1_p_d_f_rasterizer.html#af66f64089f4c6e1f989e82a75606af19", null ]
];