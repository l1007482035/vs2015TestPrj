var classpdftron_1_1_p_d_f_1_1_annots_1_1_text_widget =
[
    [ "TextWidget", "classpdftron_1_1_p_d_f_1_1_annots_1_1_text_widget.html#a1ac369933216069d9bff6bc477839f52", null ],
    [ "TextWidget", "classpdftron_1_1_p_d_f_1_1_annots_1_1_text_widget.html#a0002a42eac4e91bb3e3cdd042f928657", null ],
    [ "Create", "classpdftron_1_1_p_d_f_1_1_annots_1_1_text_widget.html#a4213b1177dac17aa21d57cf294ae044a", null ],
    [ "Create", "classpdftron_1_1_p_d_f_1_1_annots_1_1_text_widget.html#a00b57feb76811c1daad41bff07672f83", null ],
    [ "GetText", "classpdftron_1_1_p_d_f_1_1_annots_1_1_text_widget.html#aa46d8fa0d42b435335e0358eb3c9f8f9", null ],
    [ "SetText", "classpdftron_1_1_p_d_f_1_1_annots_1_1_text_widget.html#a4fb0bd908d3f1b28ef99584967da2e38", null ]
];