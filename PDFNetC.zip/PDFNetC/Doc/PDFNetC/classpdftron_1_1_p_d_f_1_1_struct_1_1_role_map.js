var classpdftron_1_1_p_d_f_1_1_struct_1_1_role_map =
[
    [ "RoleMap", "classpdftron_1_1_p_d_f_1_1_struct_1_1_role_map.html#a3b4cad49eb0356e3174f317df0c836e0", null ],
    [ "RoleMap", "classpdftron_1_1_p_d_f_1_1_struct_1_1_role_map.html#a1fca09172821633462888c4c8d5f4bae", null ],
    [ "GetDirectMap", "classpdftron_1_1_p_d_f_1_1_struct_1_1_role_map.html#ac224970eb462c484b8a3e414a30c24e0", null ],
    [ "GetSDFObj", "classpdftron_1_1_p_d_f_1_1_struct_1_1_role_map.html#a6c14b094c6e95eea1469de8330c1b7f3", null ],
    [ "IsValid", "classpdftron_1_1_p_d_f_1_1_struct_1_1_role_map.html#a3afcbbb18842eca98384bff6cc02617c", null ],
    [ "operator=", "classpdftron_1_1_p_d_f_1_1_struct_1_1_role_map.html#ae6d320e6dcaf30c76c92fe96858d8eca", null ]
];