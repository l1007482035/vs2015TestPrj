var classpdftron_1_1_p_d_f_1_1_advanced_imaging_convert_options =
[
    [ "AdvancedImagingConvertOptions", "classpdftron_1_1_p_d_f_1_1_advanced_imaging_convert_options.html#ade9b91916768c4f55927046325f17ee6", null ],
    [ "~AdvancedImagingConvertOptions", "classpdftron_1_1_p_d_f_1_1_advanced_imaging_convert_options.html#ae2ac5d34ee0dab3f364cbb61c0105f29", null ],
    [ "GetDefaultDPI", "classpdftron_1_1_p_d_f_1_1_advanced_imaging_convert_options.html#a9fb9c2294bd8a39f16b8734031ff518a", null ],
    [ "SetDefaultDPI", "classpdftron_1_1_p_d_f_1_1_advanced_imaging_convert_options.html#a2b06135d9b30e36ab7fcd5cd95be82fe", null ]
];