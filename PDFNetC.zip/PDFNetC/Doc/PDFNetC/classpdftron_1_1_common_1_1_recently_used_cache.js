var classpdftron_1_1_common_1_1_recently_used_cache =
[
    [ "AccessDocument", "classpdftron_1_1_common_1_1_recently_used_cache.html#a0c246b2f6c4c43abc8cf98e86baafd49", null ],
    [ "GetBitmapPathIfExists", "classpdftron_1_1_common_1_1_recently_used_cache.html#a30dc587dabdbc18dcb37ff476f7fe5b5", null ],
    [ "InitializeRecentlyUsedCache", "classpdftron_1_1_common_1_1_recently_used_cache.html#a0db9c689fd96e3ae007724ec6f8334db", null ],
    [ "RemoveDocument", "classpdftron_1_1_common_1_1_recently_used_cache.html#a64f925d39474a441a47d542da313f57c", null ],
    [ "ResetCache", "classpdftron_1_1_common_1_1_recently_used_cache.html#a358355a8b62eda5da8b5bf119744d06b", null ]
];