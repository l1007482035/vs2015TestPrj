var classpdftron_1_1_p_d_f_1_1_o_c_r_module =
[
    [ "ApplyOCRJsonToPDF", "classpdftron_1_1_p_d_f_1_1_o_c_r_module.html#a7cf1d79c1c9831528949ff3a92f7f38d", null ],
    [ "ApplyOCRXmlToPDF", "classpdftron_1_1_p_d_f_1_1_o_c_r_module.html#af02204bb798c00ca6c8ac1a6d823c423", null ],
    [ "GetOCRJsonFromImage", "classpdftron_1_1_p_d_f_1_1_o_c_r_module.html#a24fc1d2f9c93c83612b26aca2981aeeb", null ],
    [ "GetOCRJsonFromPDF", "classpdftron_1_1_p_d_f_1_1_o_c_r_module.html#ac91f0f99b5111f16e889ae37bd5d7c16", null ],
    [ "GetOCRXmlFromImage", "classpdftron_1_1_p_d_f_1_1_o_c_r_module.html#a5f1004900f942e24d88d47122beba24a", null ],
    [ "GetOCRXmlFromPDF", "classpdftron_1_1_p_d_f_1_1_o_c_r_module.html#a8132ec6cf6c3fa3ebc301907f71bb496", null ],
    [ "ImageToPDF", "classpdftron_1_1_p_d_f_1_1_o_c_r_module.html#ae8d5ec28bad798346148f3d8ab1978bb", null ],
    [ "IsModuleAvailable", "classpdftron_1_1_p_d_f_1_1_o_c_r_module.html#a64c2521bf9574c90b5aa11061189c1cd", null ],
    [ "ProcessPDF", "classpdftron_1_1_p_d_f_1_1_o_c_r_module.html#a799bfd436d15f6efb02521eea29ea897", null ]
];