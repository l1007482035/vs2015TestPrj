var classpdftron_1_1_common_1_1_byte_range =
[
    [ "GetEndOffset", "classpdftron_1_1_common_1_1_byte_range.html#a5f1ccc32f2cf8926b231f21be1d8ba85", null ],
    [ "GetSize", "classpdftron_1_1_common_1_1_byte_range.html#aa5bde75d06a01437d403815e1821dbbc", null ],
    [ "GetStartOffset", "classpdftron_1_1_common_1_1_byte_range.html#a212ff11c4bcddf0a641ee76ad11bb8a7", null ]
];