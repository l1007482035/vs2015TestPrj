var classpdftron_1_1_p_d_f_1_1_color_pt =
[
    [ "ColorPt", "classpdftron_1_1_p_d_f_1_1_color_pt.html#a7f80debebea1a2cf924e6050106e6f45", null ],
    [ "ColorPt", "classpdftron_1_1_p_d_f_1_1_color_pt.html#afb6c20178af08a4bc2bc1a0ac16b9baf", null ],
    [ "~ColorPt", "classpdftron_1_1_p_d_f_1_1_color_pt.html#ae7529491cbabb59c5fb4112abdbe2bea", null ],
    [ "Destroy", "classpdftron_1_1_p_d_f_1_1_color_pt.html#aa1d1477389c50ac86607907d79c38772", null ],
    [ "Get", "classpdftron_1_1_p_d_f_1_1_color_pt.html#a48644ad374c7baa26fb1901525e47a66", null ],
    [ "operator=", "classpdftron_1_1_p_d_f_1_1_color_pt.html#a809222c09ae244101cdbc744b31b2a00", null ],
    [ "operator==", "classpdftron_1_1_p_d_f_1_1_color_pt.html#a690a98633f0360784e880e548b9c3821", null ],
    [ "Set", "classpdftron_1_1_p_d_f_1_1_color_pt.html#aaadde814b27efaac3b09ed15087d7fca", null ],
    [ "Set", "classpdftron_1_1_p_d_f_1_1_color_pt.html#a84b08ec6c6e6dbc71c1c2dcde3b1ed84", null ],
    [ "SetColorantNum", "classpdftron_1_1_p_d_f_1_1_color_pt.html#a8d1e856b637c4b34a9852621f9290342", null ]
];