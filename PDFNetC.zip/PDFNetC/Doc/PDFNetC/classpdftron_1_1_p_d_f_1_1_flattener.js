var classpdftron_1_1_p_d_f_1_1_flattener =
[
    [ "FlattenMode", "classpdftron_1_1_p_d_f_1_1_flattener.html#a7830bda4a010850442fb91926679b8b0", [
      [ "e_simple", "classpdftron_1_1_p_d_f_1_1_flattener.html#a7830bda4a010850442fb91926679b8b0af72a4ba2bbcc8621af894a409f83d5fd", null ],
      [ "e_fast", "classpdftron_1_1_p_d_f_1_1_flattener.html#a7830bda4a010850442fb91926679b8b0a061c460986f142feefb375be206c8e25", null ]
    ] ],
    [ "Threshold", "classpdftron_1_1_p_d_f_1_1_flattener.html#a72a92817be465c6e5a3e0b06e8aaf8af", [
      [ "e_very_strict", "classpdftron_1_1_p_d_f_1_1_flattener.html#a72a92817be465c6e5a3e0b06e8aaf8afacbeecafc8916b44932b8d48c7254acfe", null ],
      [ "e_strict", "classpdftron_1_1_p_d_f_1_1_flattener.html#a72a92817be465c6e5a3e0b06e8aaf8afab04a27940a6880199eb5e8f8734424dc", null ],
      [ "e_default", "classpdftron_1_1_p_d_f_1_1_flattener.html#a72a92817be465c6e5a3e0b06e8aaf8afa7b78eb813c7861b4c1a74ff181e3e7f4", null ],
      [ "e_keep_most", "classpdftron_1_1_p_d_f_1_1_flattener.html#a72a92817be465c6e5a3e0b06e8aaf8afa2d0513d1cfce2a26ed022515c583eb79", null ],
      [ "e_keep_all", "classpdftron_1_1_p_d_f_1_1_flattener.html#a72a92817be465c6e5a3e0b06e8aaf8afa65dc7b9c4233a0c4b06f7b2f724c1bea", null ]
    ] ],
    [ "Flattener", "classpdftron_1_1_p_d_f_1_1_flattener.html#a33dbc23952913615b2f505ca34f56d8d", null ],
    [ "~Flattener", "classpdftron_1_1_p_d_f_1_1_flattener.html#a4c162d11cdc5027fd2c8fc6faff4950d", null ],
    [ "Destroy", "classpdftron_1_1_p_d_f_1_1_flattener.html#af736e98387f9081338901ef7b758f073", null ],
    [ "Process", "classpdftron_1_1_p_d_f_1_1_flattener.html#a92db0b299e5ef349b34ee78526a5c409", null ],
    [ "Process", "classpdftron_1_1_p_d_f_1_1_flattener.html#a7d6d8fea6e9b7f294712f79cfcc20110", null ],
    [ "SetDPI", "classpdftron_1_1_p_d_f_1_1_flattener.html#afaa2bc190dd54499a21ef444b44e1b6c", null ],
    [ "SetJPGQuality", "classpdftron_1_1_p_d_f_1_1_flattener.html#a2c0b2eebea1865f0c188949b4bc18614", null ],
    [ "SetMaximumImagePixels", "classpdftron_1_1_p_d_f_1_1_flattener.html#a65a4063e26dfdb21551ee470c44a9e8b", null ],
    [ "SetPathHinting", "classpdftron_1_1_p_d_f_1_1_flattener.html#a18e6bb73f3761b0d34af42ee16382d76", null ],
    [ "SetPreferJPG", "classpdftron_1_1_p_d_f_1_1_flattener.html#a20c3b8b1ad4f55338e3f2d4b050a70c4", null ],
    [ "SetThreshold", "classpdftron_1_1_p_d_f_1_1_flattener.html#a21b594c254ae47f60872420a53aa7c9f", null ]
];