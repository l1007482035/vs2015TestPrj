var classpdftron_1_1_p_d_f_1_1_embedded_timestamp_verification_result =
[
    [ "EmbeddedTimestampVerificationResult", "classpdftron_1_1_p_d_f_1_1_embedded_timestamp_verification_result.html#a2e134e5a41e43a89e65a85e7d08522ce", null ],
    [ "~EmbeddedTimestampVerificationResult", "classpdftron_1_1_p_d_f_1_1_embedded_timestamp_verification_result.html#af3a15343926a0329e07fa62f7942c410", null ],
    [ "EmbeddedTimestampVerificationResult", "classpdftron_1_1_p_d_f_1_1_embedded_timestamp_verification_result.html#a5a2b3a1361f5cd715d0fa99cf37f5866", null ],
    [ "Destroy", "classpdftron_1_1_p_d_f_1_1_embedded_timestamp_verification_result.html#ae6e5e106ecbf6961e78681813b101460", null ],
    [ "GetCMSDigestStatus", "classpdftron_1_1_p_d_f_1_1_embedded_timestamp_verification_result.html#ada2cb4102312ea36bd7543462d5794bb", null ],
    [ "GetCMSDigestStatusAsString", "classpdftron_1_1_p_d_f_1_1_embedded_timestamp_verification_result.html#a51379a76feaec635a50d291c0eb4f31f", null ],
    [ "GetCMSSignatureDigestAlgorithm", "classpdftron_1_1_p_d_f_1_1_embedded_timestamp_verification_result.html#a2ae7ea2e4b801ec2cf1b7280a37e1bcb", null ],
    [ "GetMessageImprintDigestAlgorithm", "classpdftron_1_1_p_d_f_1_1_embedded_timestamp_verification_result.html#a6fd5d639b6067bcb0c52415ba732faae", null ],
    [ "GetMessageImprintDigestStatus", "classpdftron_1_1_p_d_f_1_1_embedded_timestamp_verification_result.html#a6dff06cd4e2d5374db1707470059487c", null ],
    [ "GetMessageImprintDigestStatusAsString", "classpdftron_1_1_p_d_f_1_1_embedded_timestamp_verification_result.html#aaf3593089e88c361ad21862a5958a367", null ],
    [ "GetTrustStatus", "classpdftron_1_1_p_d_f_1_1_embedded_timestamp_verification_result.html#a86f91955b01aeb75d11367de6c0bcdd8", null ],
    [ "GetTrustStatusAsString", "classpdftron_1_1_p_d_f_1_1_embedded_timestamp_verification_result.html#a135e9969fc7a605e5c5c737216324c7f", null ],
    [ "GetTrustVerificationResult", "classpdftron_1_1_p_d_f_1_1_embedded_timestamp_verification_result.html#ad2066b6c19605761c26dcddb00815fea", null ],
    [ "GetUnsupportedFeatures", "classpdftron_1_1_p_d_f_1_1_embedded_timestamp_verification_result.html#ad5cb79f6d02a2aba2712c4eb622b5abd", null ],
    [ "GetVerificationStatus", "classpdftron_1_1_p_d_f_1_1_embedded_timestamp_verification_result.html#a18cc541b61ac0583739c9e736f9739d7", null ],
    [ "HasTrustVerificationResult", "classpdftron_1_1_p_d_f_1_1_embedded_timestamp_verification_result.html#ac4cbdc7ad9c1ff473ac443553e71d831", null ],
    [ "operator=", "classpdftron_1_1_p_d_f_1_1_embedded_timestamp_verification_result.html#a6c3db1080e2a525a5715c7664339ae15", null ],
    [ "m_impl", "classpdftron_1_1_p_d_f_1_1_embedded_timestamp_verification_result.html#a4121ba7d2f1cb35da37ff81e7c3ae4d4", null ]
];