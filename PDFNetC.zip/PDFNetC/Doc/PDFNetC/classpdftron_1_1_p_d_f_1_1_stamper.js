var classpdftron_1_1_p_d_f_1_1_stamper =
[
    [ "HorizontalAlignment", "classpdftron_1_1_p_d_f_1_1_stamper.html#a3ba8e9fff5f286c799506087eb4ae4df", [
      [ "e_horizontal_left", "classpdftron_1_1_p_d_f_1_1_stamper.html#a3ba8e9fff5f286c799506087eb4ae4dfa871a92f7999d2146ae83b936ca068d38", null ],
      [ "e_horizontal_center", "classpdftron_1_1_p_d_f_1_1_stamper.html#a3ba8e9fff5f286c799506087eb4ae4dfac13a79ecc1e101d7ca761bddb3ae7f9e", null ],
      [ "e_horizontal_right", "classpdftron_1_1_p_d_f_1_1_stamper.html#a3ba8e9fff5f286c799506087eb4ae4dfab68158b735d6df54dc3ad9746ac7f9f3", null ]
    ] ],
    [ "SizeType", "classpdftron_1_1_p_d_f_1_1_stamper.html#a8038e8c1ac369c4bdc0cb0c5768a2e7c", [
      [ "e_relative_scale", "classpdftron_1_1_p_d_f_1_1_stamper.html#a8038e8c1ac369c4bdc0cb0c5768a2e7ca3eeb2a368dbcb0b3c68ff627428b99c3", null ],
      [ "e_absolute_size", "classpdftron_1_1_p_d_f_1_1_stamper.html#a8038e8c1ac369c4bdc0cb0c5768a2e7ca48befeaf1c673b60565676350ee83ce4", null ],
      [ "e_font_size", "classpdftron_1_1_p_d_f_1_1_stamper.html#a8038e8c1ac369c4bdc0cb0c5768a2e7ca12589a0da2da26ca1d1a507d40fc12ff", null ]
    ] ],
    [ "TextAlignment", "classpdftron_1_1_p_d_f_1_1_stamper.html#a52718dc23de6cd03c532c6a388c333bf", [
      [ "e_align_left", "classpdftron_1_1_p_d_f_1_1_stamper.html#a52718dc23de6cd03c532c6a388c333bfa15256aaf5b397a7deaccaa4af85958ba", null ],
      [ "e_align_center", "classpdftron_1_1_p_d_f_1_1_stamper.html#a52718dc23de6cd03c532c6a388c333bfadb7074dc811a91c9f5b221d76f9680a2", null ],
      [ "e_align_right", "classpdftron_1_1_p_d_f_1_1_stamper.html#a52718dc23de6cd03c532c6a388c333bfad2f10c8c6ff99e7e5a016cd02420852e", null ]
    ] ],
    [ "VerticalAlignment", "classpdftron_1_1_p_d_f_1_1_stamper.html#a27c3e1173f3fd893392380ae98868468", [
      [ "e_vertical_bottom", "classpdftron_1_1_p_d_f_1_1_stamper.html#a27c3e1173f3fd893392380ae98868468ad1ea7ed302def7357abbffc1314f66c1", null ],
      [ "e_vertical_center", "classpdftron_1_1_p_d_f_1_1_stamper.html#a27c3e1173f3fd893392380ae98868468af40309e4941ece2c9bbbd79005b5317e", null ],
      [ "e_vertical_top", "classpdftron_1_1_p_d_f_1_1_stamper.html#a27c3e1173f3fd893392380ae98868468abe72bb6019a4b65d0f17be67f9053251", null ]
    ] ],
    [ "Stamper", "classpdftron_1_1_p_d_f_1_1_stamper.html#a8d02f75b4f4c6dcaa7a84e412ac601d0", null ],
    [ "~Stamper", "classpdftron_1_1_p_d_f_1_1_stamper.html#a3824313593a2ef92497984b6e5d931d7", null ],
    [ "DeleteStamps", "classpdftron_1_1_p_d_f_1_1_stamper.html#a0c9e9f45bf1a266ac7602506606b864f", null ],
    [ "Destroy", "classpdftron_1_1_p_d_f_1_1_stamper.html#a1948fd12fa962a9c8b0f1d4d86952d78", null ],
    [ "HasStamps", "classpdftron_1_1_p_d_f_1_1_stamper.html#a35dc39de1c42adc38861e729dd382b57", null ],
    [ "SetAlignment", "classpdftron_1_1_p_d_f_1_1_stamper.html#a8c0bf211487fc8693884433dedb5dcc5", null ],
    [ "SetAsAnnotation", "classpdftron_1_1_p_d_f_1_1_stamper.html#ad35928e5de2d7923671667fd2d06ed2c", null ],
    [ "SetAsBackground", "classpdftron_1_1_p_d_f_1_1_stamper.html#ac6413988bb43f24af2700db7a132127a", null ],
    [ "SetFont", "classpdftron_1_1_p_d_f_1_1_stamper.html#a0a6cde64d0e971da590447e7588de02f", null ],
    [ "SetFontColor", "classpdftron_1_1_p_d_f_1_1_stamper.html#a0f2beb237b507eb90cd9cedbdec8e234", null ],
    [ "SetOpacity", "classpdftron_1_1_p_d_f_1_1_stamper.html#abc6c7708ba5799dd88950fb99e8bd6e8", null ],
    [ "SetPosition", "classpdftron_1_1_p_d_f_1_1_stamper.html#a672e7100523383f83d718896b3e718b3", null ],
    [ "SetRotation", "classpdftron_1_1_p_d_f_1_1_stamper.html#a5392a422680111b538c2a910e12e9e13", null ],
    [ "SetSize", "classpdftron_1_1_p_d_f_1_1_stamper.html#a1d8f4cbacab088ab669b29a1677f429b", null ],
    [ "SetTextAlignment", "classpdftron_1_1_p_d_f_1_1_stamper.html#a0da7d3479692ec4fc533589b5e436e2c", null ],
    [ "ShowsOnPrint", "classpdftron_1_1_p_d_f_1_1_stamper.html#a1d21ec5485614e2825cd3522edbbf09a", null ],
    [ "ShowsOnScreen", "classpdftron_1_1_p_d_f_1_1_stamper.html#af91400fb44cd9bbec1849794dad227ab", null ],
    [ "StampImage", "classpdftron_1_1_p_d_f_1_1_stamper.html#a2cc467cdae5eae75d605044ee95108c6", null ],
    [ "StampPage", "classpdftron_1_1_p_d_f_1_1_stamper.html#a864feeda9e902f2295f642a0aa12250a", null ],
    [ "StampText", "classpdftron_1_1_p_d_f_1_1_stamper.html#a6001852171e941b83658b77a5f6fd89b", null ]
];