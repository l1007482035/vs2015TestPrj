var classpdftron_1_1_p_d_f_1_1_office_to_p_d_f_options =
[
    [ "OfficeToPDFOptions", "classpdftron_1_1_p_d_f_1_1_office_to_p_d_f_options.html#aad578c077ed4b958562daf8049f007d1", null ],
    [ "~OfficeToPDFOptions", "classpdftron_1_1_p_d_f_1_1_office_to_p_d_f_options.html#a4c792055b51e21bc60851f37b9dfd888", null ],
    [ "GetApplyPageBreaksToSheet", "classpdftron_1_1_p_d_f_1_1_office_to_p_d_f_options.html#a554c29aa5e6316ca52458294f8e5df95", null ],
    [ "GetDisplayChangeTracking", "classpdftron_1_1_p_d_f_1_1_office_to_p_d_f_options.html#ad8c157bb9d8f9bbe61477e46812b5c8e", null ],
    [ "GetExcelDefaultCellBorderWidth", "classpdftron_1_1_p_d_f_1_1_office_to_p_d_f_options.html#a3087478a84a60f705bd9b5c99b40af8b", null ],
    [ "GetExcelMaxAllowedCellCount", "classpdftron_1_1_p_d_f_1_1_office_to_p_d_f_options.html#aa02d7b2443fd12ac543e588b1d982bf1", null ],
    [ "GetLayoutResourcesPluginPath", "classpdftron_1_1_p_d_f_1_1_office_to_p_d_f_options.html#a29780a2d8856842bed8347fd40178269", null ],
    [ "GetLocale", "classpdftron_1_1_p_d_f_1_1_office_to_p_d_f_options.html#a38aba38e732fee85689d246b4dbd45e5", null ],
    [ "GetResourceDocPath", "classpdftron_1_1_p_d_f_1_1_office_to_p_d_f_options.html#a0d6dfae6cbccf660bbe6469d8b598573", null ],
    [ "GetSmartSubstitutionPluginPath", "classpdftron_1_1_p_d_f_1_1_office_to_p_d_f_options.html#a9b5dbcd5d4caa1e50a343aad25e803ee", null ],
    [ "GetTemplateParamsJson", "classpdftron_1_1_p_d_f_1_1_office_to_p_d_f_options.html#a7bf2202d3d3d47b7d40b30b5a283b511", null ],
    [ "SetApplyPageBreaksToSheet", "classpdftron_1_1_p_d_f_1_1_office_to_p_d_f_options.html#a44fdee2fcd4b0ccccb3823901fe2ffe3", null ],
    [ "SetDisplayChangeTracking", "classpdftron_1_1_p_d_f_1_1_office_to_p_d_f_options.html#a6e499706dce53298320c60892aff71ae", null ],
    [ "SetExcelDefaultCellBorderWidth", "classpdftron_1_1_p_d_f_1_1_office_to_p_d_f_options.html#a1282b414b8ceaeecd07f67ecaf9f6158", null ],
    [ "SetExcelMaxAllowedCellCount", "classpdftron_1_1_p_d_f_1_1_office_to_p_d_f_options.html#ad1be52a75f1fb8a78fb8829ba8756cab", null ],
    [ "SetLayoutResourcesPluginPath", "classpdftron_1_1_p_d_f_1_1_office_to_p_d_f_options.html#a8f37742ff66cc472078e38ee7b38e424", null ],
    [ "SetLocale", "classpdftron_1_1_p_d_f_1_1_office_to_p_d_f_options.html#af1d54dd42013760f27c74eb0621b407e", null ],
    [ "SetResourceDocPath", "classpdftron_1_1_p_d_f_1_1_office_to_p_d_f_options.html#aaf76ca0804a15de9932e446d74f34ee6", null ],
    [ "SetSmartSubstitutionPluginPath", "classpdftron_1_1_p_d_f_1_1_office_to_p_d_f_options.html#a0adcab5382d14b50e546bcc1bd8ab8df", null ],
    [ "SetTemplateParamsJson", "classpdftron_1_1_p_d_f_1_1_office_to_p_d_f_options.html#a6bd4f2bbdd78459274cb60e190160a66", null ]
];