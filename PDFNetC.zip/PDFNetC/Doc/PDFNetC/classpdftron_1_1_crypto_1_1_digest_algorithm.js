var classpdftron_1_1_crypto_1_1_digest_algorithm =
[
    [ "Type", "classpdftron_1_1_crypto_1_1_digest_algorithm.html#ae88a83c6af529afac85752963c0960f6", [
      [ "e_SHA1", "classpdftron_1_1_crypto_1_1_digest_algorithm.html#ae88a83c6af529afac85752963c0960f6ad05acc1e035b068283875b5b80359b6e", null ],
      [ "e_SHA256", "classpdftron_1_1_crypto_1_1_digest_algorithm.html#ae88a83c6af529afac85752963c0960f6a36895f1c44514f7b94e11a7d36c508f4", null ],
      [ "e_SHA384", "classpdftron_1_1_crypto_1_1_digest_algorithm.html#ae88a83c6af529afac85752963c0960f6a5121411ac26b300bc796b05d266629ff", null ],
      [ "e_SHA512", "classpdftron_1_1_crypto_1_1_digest_algorithm.html#ae88a83c6af529afac85752963c0960f6a50bc69b6af734183f88152fb85acbd93", null ],
      [ "e_RIPEMD160", "classpdftron_1_1_crypto_1_1_digest_algorithm.html#ae88a83c6af529afac85752963c0960f6a9b4f3e6a4f91472eb7dfb3c28e7e2ee5", null ],
      [ "e_unknown_digest_algorithm", "classpdftron_1_1_crypto_1_1_digest_algorithm.html#ae88a83c6af529afac85752963c0960f6a0b0bf3bd89de71399b94039c49d9370a", null ]
    ] ]
];