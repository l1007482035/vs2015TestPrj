var classpdftron_1_1_p_d_f_1_1_line =
[
    [ "Line", "classpdftron_1_1_p_d_f_1_1_line.html#a95a7c4e346e730204db1e28a7fef4a9f", null ],
    [ "EndsWithHyphen", "classpdftron_1_1_p_d_f_1_1_line.html#a0ea5d6beab39a976f43a0e4db41607ba", null ],
    [ "GetBBox", "classpdftron_1_1_p_d_f_1_1_line.html#a3ac81367b7b7c3c385a33df01becde52", null ],
    [ "GetCurrentNum", "classpdftron_1_1_p_d_f_1_1_line.html#a2a4e61696d0007e4b5dc16859f1a315c", null ],
    [ "GetFirstWord", "classpdftron_1_1_p_d_f_1_1_line.html#ae8387ac80892cd6c0db865705aef18c0", null ],
    [ "GetFlowID", "classpdftron_1_1_p_d_f_1_1_line.html#aebfc275dc5ae2449e46c66e058740ba7", null ],
    [ "GetNextLine", "classpdftron_1_1_p_d_f_1_1_line.html#a6b2329c1481cc86b8faf692a8ad03840", null ],
    [ "GetNumWords", "classpdftron_1_1_p_d_f_1_1_line.html#a29997465ab267ecf5537cb7709d58f57", null ],
    [ "GetParagraphID", "classpdftron_1_1_p_d_f_1_1_line.html#af6a3a9c37af46cbc9a635e9c665b4e1e", null ],
    [ "GetQuad", "classpdftron_1_1_p_d_f_1_1_line.html#aac48bf063bd106ec6b23417bdfcb16a5", null ],
    [ "GetQuad", "classpdftron_1_1_p_d_f_1_1_line.html#adc6c806af951dd90e1f7be0c13e91bd6", null ],
    [ "GetStyle", "classpdftron_1_1_p_d_f_1_1_line.html#a239975e36b6c5ce6336bff4145fb164c", null ],
    [ "GetWord", "classpdftron_1_1_p_d_f_1_1_line.html#aee4ebf25222eaf165da8a55831acbb2e", null ],
    [ "IsSimpleLine", "classpdftron_1_1_p_d_f_1_1_line.html#a0972ce541ed973730cb58fe9363ac8f0", null ],
    [ "IsValid", "classpdftron_1_1_p_d_f_1_1_line.html#a7e4943d1e21152e77da5bffbdf5ae86a", null ],
    [ "operator!=", "classpdftron_1_1_p_d_f_1_1_line.html#af145b493968dd403da4544ab3242b3ee", null ],
    [ "operator==", "classpdftron_1_1_p_d_f_1_1_line.html#a106fdada20245a28c71143bcf66241a9", null ]
];