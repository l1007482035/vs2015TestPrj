var classpdftron_1_1_p_d_f_1_1_p_d_f_doc_view_prefs =
[
    [ "PageLayout", "classpdftron_1_1_p_d_f_1_1_p_d_f_doc_view_prefs.html#ae496f411a368247d3d069a95d127037b", [
      [ "e_Default", "classpdftron_1_1_p_d_f_1_1_p_d_f_doc_view_prefs.html#ae496f411a368247d3d069a95d127037ba11681cbdd3f69b2ff2c195cd7fbb06f7", null ],
      [ "e_SinglePage", "classpdftron_1_1_p_d_f_1_1_p_d_f_doc_view_prefs.html#ae496f411a368247d3d069a95d127037baa4cd7ec29281e1fe2b0030918d698204", null ],
      [ "e_OneColumn", "classpdftron_1_1_p_d_f_1_1_p_d_f_doc_view_prefs.html#ae496f411a368247d3d069a95d127037ba807209908db6306102951d8409eca5ca", null ],
      [ "e_TwoColumnLeft", "classpdftron_1_1_p_d_f_1_1_p_d_f_doc_view_prefs.html#ae496f411a368247d3d069a95d127037ba5472c4ceb1945ea7821305de87ecefac", null ],
      [ "e_TwoColumnRight", "classpdftron_1_1_p_d_f_1_1_p_d_f_doc_view_prefs.html#ae496f411a368247d3d069a95d127037ba8047053cfdaccc35bc9af46d21c235af", null ],
      [ "e_TwoPageLeft", "classpdftron_1_1_p_d_f_1_1_p_d_f_doc_view_prefs.html#ae496f411a368247d3d069a95d127037ba7cfb9140f6836f8aff93e12be495730b", null ],
      [ "e_TwoPageRight", "classpdftron_1_1_p_d_f_1_1_p_d_f_doc_view_prefs.html#ae496f411a368247d3d069a95d127037bac478e84dabb2e3cfd5117c0a0d1eb886", null ]
    ] ],
    [ "PageMode", "classpdftron_1_1_p_d_f_1_1_p_d_f_doc_view_prefs.html#ac50d8c0da3e74046dcede17d1f80fa80", [
      [ "e_UseNone", "classpdftron_1_1_p_d_f_1_1_p_d_f_doc_view_prefs.html#ac50d8c0da3e74046dcede17d1f80fa80aa1aaa474df34e41d96d8ff1eb9d9a8d1", null ],
      [ "e_UseThumbs", "classpdftron_1_1_p_d_f_1_1_p_d_f_doc_view_prefs.html#ac50d8c0da3e74046dcede17d1f80fa80a2ffde6eb39ce932ed1be64af93b733a3", null ],
      [ "e_UseBookmarks", "classpdftron_1_1_p_d_f_1_1_p_d_f_doc_view_prefs.html#ac50d8c0da3e74046dcede17d1f80fa80ae79729c281412daa1d917ae4a0fa5989", null ],
      [ "e_FullScreen", "classpdftron_1_1_p_d_f_1_1_p_d_f_doc_view_prefs.html#ac50d8c0da3e74046dcede17d1f80fa80abf29682d063f74ba0fc966597510324b", null ],
      [ "e_UseOC", "classpdftron_1_1_p_d_f_1_1_p_d_f_doc_view_prefs.html#ac50d8c0da3e74046dcede17d1f80fa80ac8227b10f1feb6f75f7a6ba9f5a726e5", null ],
      [ "e_UseAttachments", "classpdftron_1_1_p_d_f_1_1_p_d_f_doc_view_prefs.html#ac50d8c0da3e74046dcede17d1f80fa80ac97d8c22491e0e91ab46e20ba07c3478", null ]
    ] ],
    [ "ViewerPref", "classpdftron_1_1_p_d_f_1_1_p_d_f_doc_view_prefs.html#a51439b97f0eef965b1ec58a224a89ab0", [
      [ "e_HideToolbar", "classpdftron_1_1_p_d_f_1_1_p_d_f_doc_view_prefs.html#a51439b97f0eef965b1ec58a224a89ab0ab384c1621fa44bb8d9eb0cbec97b64de", null ],
      [ "e_HideMenubar", "classpdftron_1_1_p_d_f_1_1_p_d_f_doc_view_prefs.html#a51439b97f0eef965b1ec58a224a89ab0aee0d57df8e833ac351526225a2a9e189", null ],
      [ "e_HideWindowUI", "classpdftron_1_1_p_d_f_1_1_p_d_f_doc_view_prefs.html#a51439b97f0eef965b1ec58a224a89ab0a5f694ff9330486fc2e60bf679365ea35", null ],
      [ "e_FitWindow", "classpdftron_1_1_p_d_f_1_1_p_d_f_doc_view_prefs.html#a51439b97f0eef965b1ec58a224a89ab0a1286d11cd176598a940860e7874c606c", null ],
      [ "e_CenterWindow", "classpdftron_1_1_p_d_f_1_1_p_d_f_doc_view_prefs.html#a51439b97f0eef965b1ec58a224a89ab0a2a036a1955f6e267dd309106f8cac146", null ],
      [ "e_DisplayDocTitle", "classpdftron_1_1_p_d_f_1_1_p_d_f_doc_view_prefs.html#a51439b97f0eef965b1ec58a224a89ab0abbe2842662a11be24bb80da6085cd7ab", null ]
    ] ],
    [ "PDFDocViewPrefs", "classpdftron_1_1_p_d_f_1_1_p_d_f_doc_view_prefs.html#af832698107bdcdbce46c7076cc538ead", null ],
    [ "PDFDocViewPrefs", "classpdftron_1_1_p_d_f_1_1_p_d_f_doc_view_prefs.html#a89025d6ad2a3d83da8b3a56429217b4b", null ],
    [ "PDFDocViewPrefs", "classpdftron_1_1_p_d_f_1_1_p_d_f_doc_view_prefs.html#a8a747eebd72188c8aeb7966cd04cbcb9", null ],
    [ "GetDirection", "classpdftron_1_1_p_d_f_1_1_p_d_f_doc_view_prefs.html#a4718b0918f688e161b252200fda79320", null ],
    [ "GetLayoutMode", "classpdftron_1_1_p_d_f_1_1_p_d_f_doc_view_prefs.html#ae4f00ee09361deb125445a6f100c5e5b", null ],
    [ "GetNonFullScreenPageMode", "classpdftron_1_1_p_d_f_1_1_p_d_f_doc_view_prefs.html#af20851ba2c3e4b7dfb705e166f400b8c", null ],
    [ "GetPageMode", "classpdftron_1_1_p_d_f_1_1_p_d_f_doc_view_prefs.html#ac0633a4f586b46526e1afa7458134ff1", null ],
    [ "GetPref", "classpdftron_1_1_p_d_f_1_1_p_d_f_doc_view_prefs.html#a5c75b2a933f100a994e83a4e2e05c910", null ],
    [ "GetPrintArea", "classpdftron_1_1_p_d_f_1_1_p_d_f_doc_view_prefs.html#a466130f93182b6f241d276388b1692f4", null ],
    [ "GetPrintClip", "classpdftron_1_1_p_d_f_1_1_p_d_f_doc_view_prefs.html#af1eed857d1e1363d9253fa191b8b7c57", null ],
    [ "GetSDFObj", "classpdftron_1_1_p_d_f_1_1_p_d_f_doc_view_prefs.html#a1c4df58c790d6566dae466526d987555", null ],
    [ "GetViewArea", "classpdftron_1_1_p_d_f_1_1_p_d_f_doc_view_prefs.html#ab3eb4801f10506895daa37a5a5de0d05", null ],
    [ "GetViewClip", "classpdftron_1_1_p_d_f_1_1_p_d_f_doc_view_prefs.html#afd7db8e24d7ff242d45225e529083742", null ],
    [ "operator=", "classpdftron_1_1_p_d_f_1_1_p_d_f_doc_view_prefs.html#ab3e133e55efeb688fdc5070ab348c3be", null ],
    [ "SetDirection", "classpdftron_1_1_p_d_f_1_1_p_d_f_doc_view_prefs.html#ad99311d04a6fc266360d6cf9bfc22cf0", null ],
    [ "SetInitialPage", "classpdftron_1_1_p_d_f_1_1_p_d_f_doc_view_prefs.html#a7a04f1baa79b7870569de4cae2da7e09", null ],
    [ "SetLayoutMode", "classpdftron_1_1_p_d_f_1_1_p_d_f_doc_view_prefs.html#a10ec6ededeae2712016d84d3a8b5fb7e", null ],
    [ "SetNonFullScreenPageMode", "classpdftron_1_1_p_d_f_1_1_p_d_f_doc_view_prefs.html#a01719441ecafe0f70e892bccd279eb8a", null ],
    [ "SetPageMode", "classpdftron_1_1_p_d_f_1_1_p_d_f_doc_view_prefs.html#ad800f6ffac3553e6c76bad4a9d65d837", null ],
    [ "SetPref", "classpdftron_1_1_p_d_f_1_1_p_d_f_doc_view_prefs.html#a534fdda2c684a5cdefaa669225030310", null ],
    [ "SetPrintArea", "classpdftron_1_1_p_d_f_1_1_p_d_f_doc_view_prefs.html#ac36a0e956412cd705d583e1f7233c48c", null ],
    [ "SetPrintClip", "classpdftron_1_1_p_d_f_1_1_p_d_f_doc_view_prefs.html#a5b0e85fe1362ccb5e12109e09793f1aa", null ],
    [ "SetViewArea", "classpdftron_1_1_p_d_f_1_1_p_d_f_doc_view_prefs.html#a2374d5fb38878d00a18ba957af44f778", null ],
    [ "SetViewClip", "classpdftron_1_1_p_d_f_1_1_p_d_f_doc_view_prefs.html#a14c2aa6f590753ea0652223aef1ab74a", null ]
];