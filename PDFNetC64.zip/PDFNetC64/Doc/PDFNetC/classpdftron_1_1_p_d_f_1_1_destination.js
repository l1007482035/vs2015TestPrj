var classpdftron_1_1_p_d_f_1_1_destination =
[
    [ "FitType", "classpdftron_1_1_p_d_f_1_1_destination.html#a6f85ca884bd9e6af0e7f378f8687d2cc", [
      [ "e_XYZ", "classpdftron_1_1_p_d_f_1_1_destination.html#a6f85ca884bd9e6af0e7f378f8687d2cca3d7e9dc6a4d1aa913be7ca5e59a9a2b8", null ],
      [ "e_Fit", "classpdftron_1_1_p_d_f_1_1_destination.html#a6f85ca884bd9e6af0e7f378f8687d2cca528b5fa2c44a312cbae8c314ead3c309", null ],
      [ "e_FitH", "classpdftron_1_1_p_d_f_1_1_destination.html#a6f85ca884bd9e6af0e7f378f8687d2cca36a341fdf5914e18013cf4fe34f2858c", null ],
      [ "e_FitV", "classpdftron_1_1_p_d_f_1_1_destination.html#a6f85ca884bd9e6af0e7f378f8687d2cca68e9944d619110f7c01c4ed5e49df023", null ],
      [ "e_FitR", "classpdftron_1_1_p_d_f_1_1_destination.html#a6f85ca884bd9e6af0e7f378f8687d2cca72cf9a471ba1d4a9ca4c6a7b6af337a5", null ],
      [ "e_FitB", "classpdftron_1_1_p_d_f_1_1_destination.html#a6f85ca884bd9e6af0e7f378f8687d2cca8c8324c89904bca44ca01eb94ab775ef", null ],
      [ "e_FitBH", "classpdftron_1_1_p_d_f_1_1_destination.html#a6f85ca884bd9e6af0e7f378f8687d2cca8be4e0e4b26b2b94ca2753b06df7a13d", null ],
      [ "e_FitBV", "classpdftron_1_1_p_d_f_1_1_destination.html#a6f85ca884bd9e6af0e7f378f8687d2ccad05930f65b40480721692b4363ff5d9e", null ]
    ] ],
    [ "Destination", "classpdftron_1_1_p_d_f_1_1_destination.html#acaf6f7fad7a521c008d701bc3ed5365f", null ],
    [ "Destination", "classpdftron_1_1_p_d_f_1_1_destination.html#ab55c31536d119dd66dc9f4502a20555c", null ],
    [ "Destination", "classpdftron_1_1_p_d_f_1_1_destination.html#af5916bbfd5e2a9a3d0eb10f78e0929bf", null ],
    [ "Destination", "classpdftron_1_1_p_d_f_1_1_destination.html#a330f9b80211c1e6b230e82b7c6551024", null ],
    [ "CreateFit", "classpdftron_1_1_p_d_f_1_1_destination.html#aa7a7df6be38d30b5f9b85018dd2943ff", null ],
    [ "CreateFitB", "classpdftron_1_1_p_d_f_1_1_destination.html#a231b32c5688f1d4db73d6fa26dd36d9a", null ],
    [ "CreateFitBH", "classpdftron_1_1_p_d_f_1_1_destination.html#aa9b425091981ba2ee6035e976afcb633", null ],
    [ "CreateFitBV", "classpdftron_1_1_p_d_f_1_1_destination.html#ade0256c82e2e35ce24627df34b22276c", null ],
    [ "CreateFitH", "classpdftron_1_1_p_d_f_1_1_destination.html#a45790ba895c919f2821658d4777366ea", null ],
    [ "CreateFitR", "classpdftron_1_1_p_d_f_1_1_destination.html#af68c3b7919e99c339bfc2f7556ad0cff", null ],
    [ "CreateFitV", "classpdftron_1_1_p_d_f_1_1_destination.html#ac0a3baa6916f609e5376c79210caa6cc", null ],
    [ "CreateXYZ", "classpdftron_1_1_p_d_f_1_1_destination.html#a43107cc10764c2ef248e0a6c225b7fac", null ],
    [ "GetExplicitDestObj", "classpdftron_1_1_p_d_f_1_1_destination.html#aa9cbb49a1f9c05c39cebfecdf66b50b6", null ],
    [ "GetFitType", "classpdftron_1_1_p_d_f_1_1_destination.html#a00f519eeb127d7141c1a548a02e1d24f", null ],
    [ "GetPage", "classpdftron_1_1_p_d_f_1_1_destination.html#afb2d1bf172cf715bb24c10e25b3fce07", null ],
    [ "GetSDFObj", "classpdftron_1_1_p_d_f_1_1_destination.html#a755814edfa49fe7b4393257b03a0b553", null ],
    [ "IsValid", "classpdftron_1_1_p_d_f_1_1_destination.html#a34cd5d719ce2664d88b2e27d63b451eb", null ],
    [ "operator=", "classpdftron_1_1_p_d_f_1_1_destination.html#ac829bdb0e46b318ccd87806baa8f6898", null ],
    [ "SetPage", "classpdftron_1_1_p_d_f_1_1_destination.html#a0de122af91a37fa3bd8d20c617baeb10", null ]
];