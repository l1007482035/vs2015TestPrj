var classpdftron_1_1_p_d_f_1_1_annots_1_1_markup =
[
    [ "BorderEffect", "classpdftron_1_1_p_d_f_1_1_annots_1_1_markup.html#a2cf0263c79690169a3b27205c0663552", [
      [ "e_None", "classpdftron_1_1_p_d_f_1_1_annots_1_1_markup.html#a2cf0263c79690169a3b27205c0663552a386d9057c89a319065d304f700faf18f", null ],
      [ "e_Cloudy", "classpdftron_1_1_p_d_f_1_1_annots_1_1_markup.html#a2cf0263c79690169a3b27205c0663552aabd5ec88b866271c7ce9cba66ed8adae", null ]
    ] ],
    [ "Markup", "classpdftron_1_1_p_d_f_1_1_annots_1_1_markup.html#a2d7c7a544ed7d9cf1e2535a518726e5f", null ],
    [ "Markup", "classpdftron_1_1_p_d_f_1_1_annots_1_1_markup.html#a1cb949c5547fd6364fedcfd81be4d906", null ],
    [ "GetBorderEffect", "classpdftron_1_1_p_d_f_1_1_annots_1_1_markup.html#a1336743c6e49f5e6051c199cc2926827", null ],
    [ "GetBorderEffectIntensity", "classpdftron_1_1_p_d_f_1_1_annots_1_1_markup.html#ac6d86802aead0c009a1a32802a321b4d", null ],
    [ "GetContentRect", "classpdftron_1_1_p_d_f_1_1_annots_1_1_markup.html#ac340a87b5a8ce23022b2617c7fdfc499", null ],
    [ "GetCreationDates", "classpdftron_1_1_p_d_f_1_1_annots_1_1_markup.html#a524b643b4a152c7d03b305ea42b215ad", null ],
    [ "GetInteriorColor", "classpdftron_1_1_p_d_f_1_1_annots_1_1_markup.html#af9aad2129cb651215f4b01f0ccb0961e", null ],
    [ "GetInteriorColorCompNum", "classpdftron_1_1_p_d_f_1_1_annots_1_1_markup.html#a3f292900f154fbeaafe5f85b323db5fc", null ],
    [ "GetOpacity", "classpdftron_1_1_p_d_f_1_1_annots_1_1_markup.html#a73a6f98e0c5cd9854a7a237a3c6908a5", null ],
    [ "GetPadding", "classpdftron_1_1_p_d_f_1_1_annots_1_1_markup.html#a631eeffe4d7cf22b9bd7acd939b1da5e", null ],
    [ "GetPopup", "classpdftron_1_1_p_d_f_1_1_annots_1_1_markup.html#af19ff3f536ea96b0b2fe95f239f25352", null ],
    [ "GetSubject", "classpdftron_1_1_p_d_f_1_1_annots_1_1_markup.html#a1e99432a56ae86e940a19298ee94182b", null ],
    [ "GetTitle", "classpdftron_1_1_p_d_f_1_1_annots_1_1_markup.html#a594932d299fb38ea1939226efb5e4c44", null ],
    [ "RotateAppearance", "classpdftron_1_1_p_d_f_1_1_annots_1_1_markup.html#a57a48a97db764212ebf105a5d2708491", null ],
    [ "SetBorderEffect", "classpdftron_1_1_p_d_f_1_1_annots_1_1_markup.html#a69d63b7a555ae12b4a54ce3cf437cfaf", null ],
    [ "SetBorderEffectIntensity", "classpdftron_1_1_p_d_f_1_1_annots_1_1_markup.html#ace6aa0277257092bee3e0ff0db4d94cd", null ],
    [ "SetContentRect", "classpdftron_1_1_p_d_f_1_1_annots_1_1_markup.html#a4c433d5179e8b95a7b4517d984442af1", null ],
    [ "SetCreationDates", "classpdftron_1_1_p_d_f_1_1_annots_1_1_markup.html#aa154bf60444f6f77eb915bbcf3669301", null ],
    [ "SetInteriorColor", "classpdftron_1_1_p_d_f_1_1_annots_1_1_markup.html#a5969bf3e912a50b007c68a5c1c8fe432", null ],
    [ "SetOpacity", "classpdftron_1_1_p_d_f_1_1_annots_1_1_markup.html#a79bac79f586e96c0e89d396c43dc4e51", null ],
    [ "SetPadding", "classpdftron_1_1_p_d_f_1_1_annots_1_1_markup.html#af551740458bdd1445b6194287d264985", null ],
    [ "SetPadding", "classpdftron_1_1_p_d_f_1_1_annots_1_1_markup.html#a1859371cb1ea9961657b930da172f7aa", null ],
    [ "SetPopup", "classpdftron_1_1_p_d_f_1_1_annots_1_1_markup.html#a42103e3cf2d1f5916187d778f0b3b220", null ],
    [ "SetSubject", "classpdftron_1_1_p_d_f_1_1_annots_1_1_markup.html#a394dbaf18469b6bf068f984f980a0771", null ],
    [ "SetTitle", "classpdftron_1_1_p_d_f_1_1_annots_1_1_markup.html#a0973b3639875b54879b9f1a683dbd057", null ],
    [ "SetTitle", "classpdftron_1_1_p_d_f_1_1_annots_1_1_markup.html#a1a7f00f1b0b5f81a40b1ca3dbae7be65", null ]
];