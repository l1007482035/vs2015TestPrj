var classpdftron_1_1_p_d_f_1_1_rect_collection =
[
    [ "RectCollection", "classpdftron_1_1_p_d_f_1_1_rect_collection.html#a5944277fb7861eb0922c305622b843ec", null ],
    [ "AddRect", "classpdftron_1_1_p_d_f_1_1_rect_collection.html#afe551812f40ea8ba76b817215f560225", null ],
    [ "AddRect", "classpdftron_1_1_p_d_f_1_1_rect_collection.html#a9cfd089e5364363004f5174f96ee9d11", null ],
    [ "Clear", "classpdftron_1_1_p_d_f_1_1_rect_collection.html#a9a9b5e46cd3cff1c177ae0842d50b632", null ],
    [ "GetNumRects", "classpdftron_1_1_p_d_f_1_1_rect_collection.html#a7fde0d3cf53d41bd64ccbcb4cd71478f", null ],
    [ "GetRectAt", "classpdftron_1_1_p_d_f_1_1_rect_collection.html#a5125471c54daf68bfa32b1073c46d1a9", null ]
];