var classpdftron_1_1_p_d_f_1_1_optimizer =
[
    [ "ImageSettings", "classpdftron_1_1_p_d_f_1_1_optimizer.html#afc42e76363aec3b4710feda8dd5b996b", null ],
    [ "MonoImageSettings", "classpdftron_1_1_p_d_f_1_1_optimizer.html#a4caa64ff094984cea81c107c333a1c68", null ],
    [ "OptimizerSettings", "classpdftron_1_1_p_d_f_1_1_optimizer.html#a17091582f3122636492b92d1ba6520b7", null ],
    [ "TextSettings", "classpdftron_1_1_p_d_f_1_1_optimizer.html#af6612e8de51549a9ff2205177c9843f6", null ],
    [ "Optimize", "classpdftron_1_1_p_d_f_1_1_optimizer.html#afcf375a0defe6c519da72a7fcd55216e", null ],
    [ "Optimize", "classpdftron_1_1_p_d_f_1_1_optimizer.html#a0a7496f85ad5847b96e046a3d176339d", null ]
];