var classpdftron_1_1_p_d_f_1_1_h_t_m_l_output_options =
[
    [ "ContentReflowSetting", "classpdftron_1_1_p_d_f_1_1_h_t_m_l_output_options.html#a5663cc42b71004272941c6974855b9dc", [
      [ "e_fixed_position", "classpdftron_1_1_p_d_f_1_1_h_t_m_l_output_options.html#a5663cc42b71004272941c6974855b9dcad579d9dbad7f9544890f1729a23ed3a1", null ],
      [ "e_reflow_paragraphs", "classpdftron_1_1_p_d_f_1_1_h_t_m_l_output_options.html#a5663cc42b71004272941c6974855b9dca2a09fa3939a01401be7450b0ff79ef13", null ]
    ] ],
    [ "SearchableImageSetting", "classpdftron_1_1_p_d_f_1_1_h_t_m_l_output_options.html#a6a1b50c1f64f824ffc2831ed45e2d3d2", [
      [ "e_ocr_image_text", "classpdftron_1_1_p_d_f_1_1_h_t_m_l_output_options.html#a6a1b50c1f64f824ffc2831ed45e2d3d2a7ea48ede960a03e4b996e913b5a2393a", null ],
      [ "e_ocr_image", "classpdftron_1_1_p_d_f_1_1_h_t_m_l_output_options.html#a6a1b50c1f64f824ffc2831ed45e2d3d2ae5bef0b72ffacc38f3d6d450cab39c53", null ],
      [ "e_ocr_text", "classpdftron_1_1_p_d_f_1_1_h_t_m_l_output_options.html#a6a1b50c1f64f824ffc2831ed45e2d3d2a3114c3212695b87ac91c67ef15239f5b", null ]
    ] ],
    [ "HTMLOutputOptions", "classpdftron_1_1_p_d_f_1_1_h_t_m_l_output_options.html#a03362676c60f3c418dd14625b68eb3ce", null ],
    [ "SetConnectHyphens", "classpdftron_1_1_p_d_f_1_1_h_t_m_l_output_options.html#a35022fdeb50686f5ff5a5beeb9b4da6f", null ],
    [ "SetContentReflowSetting", "classpdftron_1_1_p_d_f_1_1_h_t_m_l_output_options.html#a849dfc8b9a7cd7b09e2307c19456c5e2", null ],
    [ "SetDisableVerticalSplit", "classpdftron_1_1_p_d_f_1_1_h_t_m_l_output_options.html#a905d210ff0002786b4fa7239ed948c22", null ],
    [ "SetDPI", "classpdftron_1_1_p_d_f_1_1_h_t_m_l_output_options.html#a66794e205cd76c73be933cd8c3a49a89", null ],
    [ "SetEmbedImages", "classpdftron_1_1_p_d_f_1_1_h_t_m_l_output_options.html#a199b3c05cc4336549e97434862393a93", null ],
    [ "SetExternalLinks", "classpdftron_1_1_p_d_f_1_1_h_t_m_l_output_options.html#a9dd3b7b98ed003143e66cbc0b381cdb0", null ],
    [ "SetFileConversionTimeoutSeconds", "classpdftron_1_1_p_d_f_1_1_h_t_m_l_output_options.html#adc551ab08a3e2b426597e186f3f19fbc", null ],
    [ "SetImageDPI", "classpdftron_1_1_p_d_f_1_1_h_t_m_l_output_options.html#aef3824fafa46d78047e0bf7f16726a37", null ],
    [ "SetInternalLinks", "classpdftron_1_1_p_d_f_1_1_h_t_m_l_output_options.html#abe99552dba70b39825ecfaffee43dba9", null ],
    [ "SetJPGQuality", "classpdftron_1_1_p_d_f_1_1_h_t_m_l_output_options.html#a27274a83880bbcb17b92a16a4062afd5", null ],
    [ "SetMaximumImagePixels", "classpdftron_1_1_p_d_f_1_1_h_t_m_l_output_options.html#a974095533be3e8143510ec6a6237e4ab", null ],
    [ "SetNoPageWidth", "classpdftron_1_1_p_d_f_1_1_h_t_m_l_output_options.html#a22c656ca2a931e89393bb02be1786d02", null ],
    [ "SetPages", "classpdftron_1_1_p_d_f_1_1_h_t_m_l_output_options.html#aa57b20046885e88b5d97adf51448c7e8", null ],
    [ "SetPDFPassword", "classpdftron_1_1_p_d_f_1_1_h_t_m_l_output_options.html#a59ced2ca9217fa575f32c7d623448820", null ],
    [ "SetPreferJPG", "classpdftron_1_1_p_d_f_1_1_h_t_m_l_output_options.html#ae197408750593cd8dd6991e909ac31fa", null ],
    [ "SetReportFile", "classpdftron_1_1_p_d_f_1_1_h_t_m_l_output_options.html#aadb1105d3a2b26db344f96ecf9698dae", null ],
    [ "SetScale", "classpdftron_1_1_p_d_f_1_1_h_t_m_l_output_options.html#a093d38248f45e330a632d37d1d57b000", null ],
    [ "SetSearchableImageSetting", "classpdftron_1_1_p_d_f_1_1_h_t_m_l_output_options.html#a1efb61c37daf16b3480795f03b2afa71", null ],
    [ "SetSimpleLists", "classpdftron_1_1_p_d_f_1_1_h_t_m_l_output_options.html#a75ff9c3376fc2674dabb13f44cd802bf", null ],
    [ "SetSimplifyText", "classpdftron_1_1_p_d_f_1_1_h_t_m_l_output_options.html#a0596aca2fc90bf9a3ded3f7daeb84215", null ],
    [ "SetTitle", "classpdftron_1_1_p_d_f_1_1_h_t_m_l_output_options.html#a51a9c5ffabde9d138ef9c058f0561e41", null ],
    [ "Convert", "classpdftron_1_1_p_d_f_1_1_h_t_m_l_output_options.html#a2d2f4f747b784412804ac6e44390cf1f", null ],
    [ "m_obj", "classpdftron_1_1_p_d_f_1_1_h_t_m_l_output_options.html#a9abe15dc9dceb990e1d62bcaf395d296", null ],
    [ "m_objset", "classpdftron_1_1_p_d_f_1_1_h_t_m_l_output_options.html#aeeea3a22293186735d1255da19c1183b", null ]
];