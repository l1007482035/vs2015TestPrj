var classpdftron_1_1_p_d_f_1_1_annots_1_1_file_attachment =
[
    [ "Icon", "classpdftron_1_1_p_d_f_1_1_annots_1_1_file_attachment.html#abf219013fed5703c456dda9512a6b008", [
      [ "e_Graph", "classpdftron_1_1_p_d_f_1_1_annots_1_1_file_attachment.html#abf219013fed5703c456dda9512a6b008a26d4e2a2762120b48e2b70f91b5fcc23", null ],
      [ "e_PushPin", "classpdftron_1_1_p_d_f_1_1_annots_1_1_file_attachment.html#abf219013fed5703c456dda9512a6b008a552a03a8844a8b6f258bc64684df20c2", null ],
      [ "e_Paperclip", "classpdftron_1_1_p_d_f_1_1_annots_1_1_file_attachment.html#abf219013fed5703c456dda9512a6b008a0bcd0ca7e35ff76ac011c3c78aa37e3b", null ],
      [ "e_Tag", "classpdftron_1_1_p_d_f_1_1_annots_1_1_file_attachment.html#abf219013fed5703c456dda9512a6b008a5eb96d805cca781189b38b1211ce9404", null ],
      [ "e_Unknown", "classpdftron_1_1_p_d_f_1_1_annots_1_1_file_attachment.html#abf219013fed5703c456dda9512a6b008ab34e3a8d2f7cc716193688efa25a7a71", null ]
    ] ],
    [ "FileAttachment", "classpdftron_1_1_p_d_f_1_1_annots_1_1_file_attachment.html#a1ee05fb561b9ca077b88b683d2baa501", null ],
    [ "FileAttachment", "classpdftron_1_1_p_d_f_1_1_annots_1_1_file_attachment.html#ad8a8d7b4a2c5e9970f4a3a23a9030cb4", null ],
    [ "Create", "classpdftron_1_1_p_d_f_1_1_annots_1_1_file_attachment.html#ae27ddc63abf289a823f46fc321ffe872", null ],
    [ "Create", "classpdftron_1_1_p_d_f_1_1_annots_1_1_file_attachment.html#a7bff46109a09753eb5d68c0c1b4d82e7", null ],
    [ "Create", "classpdftron_1_1_p_d_f_1_1_annots_1_1_file_attachment.html#a7d0ca3d8930c84df95e39d06b5bbe2ea", null ],
    [ "Export", "classpdftron_1_1_p_d_f_1_1_annots_1_1_file_attachment.html#a7bc0fde235412e118fd3cce9fcfb1812", null ],
    [ "GetFileSpec", "classpdftron_1_1_p_d_f_1_1_annots_1_1_file_attachment.html#ad7d497b7fb081d492a17290cfc1cacb3", null ],
    [ "GetIcon", "classpdftron_1_1_p_d_f_1_1_annots_1_1_file_attachment.html#ad08188f9033a2a13aada2db88d50d73a", null ],
    [ "GetIconName", "classpdftron_1_1_p_d_f_1_1_annots_1_1_file_attachment.html#a3f6c356919f85ced9a101c9283928dd4", null ],
    [ "SetFileSpec", "classpdftron_1_1_p_d_f_1_1_annots_1_1_file_attachment.html#aa58a3818d25255af800b1d701475eb63", null ],
    [ "SetIcon", "classpdftron_1_1_p_d_f_1_1_annots_1_1_file_attachment.html#a1bea560a8ca7e459af7a5087b0dd83e2", null ],
    [ "SetIconName", "classpdftron_1_1_p_d_f_1_1_annots_1_1_file_attachment.html#a272f70bb1c83003ac043ef4b3b38cbc1", null ]
];