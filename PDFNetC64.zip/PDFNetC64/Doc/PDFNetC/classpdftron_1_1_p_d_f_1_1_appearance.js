var classpdftron_1_1_p_d_f_1_1_appearance =
[
    [ "Appearance", "classpdftron_1_1_p_d_f_1_1_appearance.html#a3f8e28e77dcfc7600457930cd46cf958", null ],
    [ "Border", "classpdftron_1_1_p_d_f_1_1_appearance.html#a1a1175954457d31f39dc1a524cd8441d", null ],
    [ "HorizTextAlignment", "classpdftron_1_1_p_d_f_1_1_appearance.html#a7255b87125a23743f7bad05794804fc6", null ],
    [ "MaxFontSize", "classpdftron_1_1_p_d_f_1_1_appearance.html#aec62c9bc729ca563650ed24c48b6691b", null ],
    [ "MinFontSize", "classpdftron_1_1_p_d_f_1_1_appearance.html#a152ad3b68d66cdd59fc8aa584367de3c", null ],
    [ "NegativeOverlayColor", "classpdftron_1_1_p_d_f_1_1_appearance.html#a07d2e48ab617f521cd470d78a7320344", null ],
    [ "PositiveOverlayColor", "classpdftron_1_1_p_d_f_1_1_appearance.html#a03ed420da6099db085da0cf9a7fe11b5", null ],
    [ "RedactedContentColor", "classpdftron_1_1_p_d_f_1_1_appearance.html#aea6d85a6aa1daca79d3be794f305f752", null ],
    [ "RedactionOverlay", "classpdftron_1_1_p_d_f_1_1_appearance.html#adfed264ae4468eb3283d8d416e9215b0", null ],
    [ "ShowRedactedContentRegions", "classpdftron_1_1_p_d_f_1_1_appearance.html#a22e4c595c9e5972bfa41f4742df85b17", null ],
    [ "TextColor", "classpdftron_1_1_p_d_f_1_1_appearance.html#aba5e4021ffe461b56a535ed8ee146bc3", null ],
    [ "TextFont", "classpdftron_1_1_p_d_f_1_1_appearance.html#a43f2561d94aad39d744a25358c3ba565", null ],
    [ "UseOverlayText", "classpdftron_1_1_p_d_f_1_1_appearance.html#af0caaca2bd65c11a3c073b5446c05c3a", null ],
    [ "VertTextAlignment", "classpdftron_1_1_p_d_f_1_1_appearance.html#aa04a15fc92e2b685d1fecd5475e5ecaf", null ]
];