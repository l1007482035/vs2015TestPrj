var classpdftron_1_1_p_d_f_1_1_e_p_u_b_output_options =
[
    [ "EPUBOutputOptions", "classpdftron_1_1_p_d_f_1_1_e_p_u_b_output_options.html#a5b589bb49b1a5581339cbc5ed712da75", null ],
    [ "SetExpanded", "classpdftron_1_1_p_d_f_1_1_e_p_u_b_output_options.html#a2c0052f3a529d2065607f62d3d99972f", null ],
    [ "SetReuseCover", "classpdftron_1_1_p_d_f_1_1_e_p_u_b_output_options.html#ac176241611238f3df315b351425523f1", null ],
    [ "Convert", "classpdftron_1_1_p_d_f_1_1_e_p_u_b_output_options.html#a2d2f4f747b784412804ac6e44390cf1f", null ],
    [ "m_obj", "classpdftron_1_1_p_d_f_1_1_e_p_u_b_output_options.html#aeda9c51cafb65757ba6601c89a042d4b", null ],
    [ "m_objset", "classpdftron_1_1_p_d_f_1_1_e_p_u_b_output_options.html#a47a629d9bfac195ebc33ed685d730785", null ]
];