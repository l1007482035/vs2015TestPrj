var classpdftron_1_1_filters_1_1_mapped_file =
[
    [ "MappedFile", "classpdftron_1_1_filters_1_1_mapped_file.html#add02216af0bdba8a0dcc76dc39c19a8a", null ],
    [ "Equivalent", "classpdftron_1_1_filters_1_1_mapped_file.html#a13144c60292654a875ee22248d4be6ec", null ],
    [ "FileSize", "classpdftron_1_1_filters_1_1_mapped_file.html#a4ec8509527964c3ec1b84687441acfac", null ],
    [ "operator==", "classpdftron_1_1_filters_1_1_mapped_file.html#a192316c79e2ef1412a895ee570533e7f", null ]
];