var classpdftron_1_1_p_d_f_1_1_border_style =
[
    [ "Style", "classpdftron_1_1_p_d_f_1_1_border_style.html#afce0a5b3808af6a9f7f042531496bee9", [
      [ "e_solid", "classpdftron_1_1_p_d_f_1_1_border_style.html#afce0a5b3808af6a9f7f042531496bee9a444ae6a1549b55bfbb8d6ebd9269e1a8", null ],
      [ "e_dashed", "classpdftron_1_1_p_d_f_1_1_border_style.html#afce0a5b3808af6a9f7f042531496bee9a39f44defc81bd21ee54cd28f9c10a0b8", null ],
      [ "e_beveled", "classpdftron_1_1_p_d_f_1_1_border_style.html#afce0a5b3808af6a9f7f042531496bee9a40795e104a5cde2a4e1f7a9c48d4e113", null ],
      [ "e_inset", "classpdftron_1_1_p_d_f_1_1_border_style.html#afce0a5b3808af6a9f7f042531496bee9a3efd9aaa77cf9fcb6fbfb5268b9836c9", null ],
      [ "e_underline", "classpdftron_1_1_p_d_f_1_1_border_style.html#afce0a5b3808af6a9f7f042531496bee9aa77549e35463bdec3b5ee5f7ad340279", null ]
    ] ],
    [ "BorderStyle", "classpdftron_1_1_p_d_f_1_1_border_style.html#a06c3f68e5c698e2c6daa7cf6e53d8b9d", null ],
    [ "BorderStyle", "classpdftron_1_1_p_d_f_1_1_border_style.html#a060a367ec29e0966d21086371ba5714b", null ],
    [ "BorderStyle", "classpdftron_1_1_p_d_f_1_1_border_style.html#ab5feeb774f4dfd0fd83fc930a69aee45", null ],
    [ "~BorderStyle", "classpdftron_1_1_p_d_f_1_1_border_style.html#aa26f0c66f492e6c2937eefc8905c1ce7", null ],
    [ "BorderStyle", "classpdftron_1_1_p_d_f_1_1_border_style.html#a4f36729778406caa4ec609834976d5a6", null ],
    [ "BorderStyle", "classpdftron_1_1_p_d_f_1_1_border_style.html#ac70063a590b57b38c979dd60e97fc309", null ],
    [ "Destroy", "classpdftron_1_1_p_d_f_1_1_border_style.html#ac3db4f1e240e90b66ab5457ac36b5b7e", null ],
    [ "GetDash", "classpdftron_1_1_p_d_f_1_1_border_style.html#aca635a652bf9a3719f1db2f16ecbe1f8", null ],
    [ "GetHR", "classpdftron_1_1_p_d_f_1_1_border_style.html#a56d7aaa3d3b01feb8e9a75114b80b5cf", null ],
    [ "GetStyle", "classpdftron_1_1_p_d_f_1_1_border_style.html#afc55acde4288622a4b5beaca63ed5ce7", null ],
    [ "GetVR", "classpdftron_1_1_p_d_f_1_1_border_style.html#a4c14fe73df11a417957fcc78233371ff", null ],
    [ "GetWidth", "classpdftron_1_1_p_d_f_1_1_border_style.html#a4019cbef6a689f96726f6e7fc44fd672", null ],
    [ "operator=", "classpdftron_1_1_p_d_f_1_1_border_style.html#ae0cf628029ea7b8f7da2097474a60ddf", null ],
    [ "SetDash", "classpdftron_1_1_p_d_f_1_1_border_style.html#addd8da0b83918f24855a901b25ac7f9b", null ],
    [ "SetHR", "classpdftron_1_1_p_d_f_1_1_border_style.html#adefecdf325fbc78be57e854799b25959", null ],
    [ "SetStyle", "classpdftron_1_1_p_d_f_1_1_border_style.html#a6a3c9c56bd34286c90b05c0f72e950fd", null ],
    [ "SetVR", "classpdftron_1_1_p_d_f_1_1_border_style.html#a624085d1b674caa2ae2598912bfda0bf", null ],
    [ "SetWidth", "classpdftron_1_1_p_d_f_1_1_border_style.html#aeb2ec7da7b181967ab5200647be8ee37", null ],
    [ "operator!=", "classpdftron_1_1_p_d_f_1_1_border_style.html#a8fcc7bb192e371c5f7a45a37dbd21d09", null ],
    [ "operator==", "classpdftron_1_1_p_d_f_1_1_border_style.html#a98a4b870bcb24de8768a9a0396ad7c07", null ],
    [ "PDF::Annot", "classpdftron_1_1_p_d_f_1_1_border_style.html#a1afae365b8b488ac9e3b09316d129780", null ]
];