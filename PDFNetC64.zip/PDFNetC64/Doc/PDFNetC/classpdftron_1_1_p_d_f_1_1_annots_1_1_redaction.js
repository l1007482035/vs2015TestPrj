var classpdftron_1_1_p_d_f_1_1_annots_1_1_redaction =
[
    [ "QuadForm", "classpdftron_1_1_p_d_f_1_1_annots_1_1_redaction.html#ac79057a4c8aadbe3fb564071b365a9be", [
      [ "e_LeftJustified", "classpdftron_1_1_p_d_f_1_1_annots_1_1_redaction.html#ac79057a4c8aadbe3fb564071b365a9beab880f927b0ef8f04dee3198bd3821d78", null ],
      [ "e_Centered", "classpdftron_1_1_p_d_f_1_1_annots_1_1_redaction.html#ac79057a4c8aadbe3fb564071b365a9beae5967e719ee1417f369e5f0529e79915", null ],
      [ "e_RightJustified", "classpdftron_1_1_p_d_f_1_1_annots_1_1_redaction.html#ac79057a4c8aadbe3fb564071b365a9beae7fece2ac5a525c3acd4997636ae238b", null ],
      [ "e_None", "classpdftron_1_1_p_d_f_1_1_annots_1_1_redaction.html#ac79057a4c8aadbe3fb564071b365a9beab7a55aba0507bbf1984010dab34ccd90", null ]
    ] ],
    [ "Redaction", "classpdftron_1_1_p_d_f_1_1_annots_1_1_redaction.html#a4d905248cb8ed46d176205b76db7fcff", null ],
    [ "Redaction", "classpdftron_1_1_p_d_f_1_1_annots_1_1_redaction.html#aefe060c1ae81456c8d30f0044cc7b4d0", null ],
    [ "Create", "classpdftron_1_1_p_d_f_1_1_annots_1_1_redaction.html#a8dee3865e817ac39c9b0c1bf855673fa", null ],
    [ "GetAppFormXO", "classpdftron_1_1_p_d_f_1_1_annots_1_1_redaction.html#ac61901e4904feafbb740ed6a70b85db3", null ],
    [ "GetOverlayText", "classpdftron_1_1_p_d_f_1_1_annots_1_1_redaction.html#a443ad37f6eac009fdb9811481fc96c83", null ],
    [ "GetOverlayTextAppearance", "classpdftron_1_1_p_d_f_1_1_annots_1_1_redaction.html#ae6a2107a684cc818bbcf127476e91608", null ],
    [ "GetQuadForm", "classpdftron_1_1_p_d_f_1_1_annots_1_1_redaction.html#a906d457f073c5afe613f5fdfab8b3ac6", null ],
    [ "GetQuadPoint", "classpdftron_1_1_p_d_f_1_1_annots_1_1_redaction.html#ad3006405038bb5282ac1134684ae24be", null ],
    [ "GetQuadPointCount", "classpdftron_1_1_p_d_f_1_1_annots_1_1_redaction.html#a173e938ea99a2cc95b6c4f855948eead", null ],
    [ "GetUseRepeat", "classpdftron_1_1_p_d_f_1_1_annots_1_1_redaction.html#a0138e8c2529d83876f978346f6be7d9e", null ],
    [ "SetAppFormXO", "classpdftron_1_1_p_d_f_1_1_annots_1_1_redaction.html#ac862921ed75a786f9fed3d4b7c1465d6", null ],
    [ "SetOverlayText", "classpdftron_1_1_p_d_f_1_1_annots_1_1_redaction.html#a52fad4de5c55d899ae65b4430a9355d3", null ],
    [ "SetOverlayTextAppearance", "classpdftron_1_1_p_d_f_1_1_annots_1_1_redaction.html#a4673864ca55457d65c00c83c725680b4", null ],
    [ "SetQuadForm", "classpdftron_1_1_p_d_f_1_1_annots_1_1_redaction.html#a1ed54e2208cb1565657b24ec00e2fb7f", null ],
    [ "SetQuadPoint", "classpdftron_1_1_p_d_f_1_1_annots_1_1_redaction.html#a18cf928cc7d0b856d6a4f40a835ea997", null ],
    [ "SetUseRepeat", "classpdftron_1_1_p_d_f_1_1_annots_1_1_redaction.html#a6756a77a6846089a632f74dddf5f4371", null ]
];