var classpdftron_1_1_p_d_f_1_1_file_spec =
[
    [ "FileSpec", "classpdftron_1_1_p_d_f_1_1_file_spec.html#a4c42c8811dc17756bf400ca43380143c", null ],
    [ "FileSpec", "classpdftron_1_1_p_d_f_1_1_file_spec.html#a625cb43e60f68f796ed1a45252f15288", null ],
    [ "FileSpec", "classpdftron_1_1_p_d_f_1_1_file_spec.html#a9015c9cb819b3f4acd01a3b4b919badd", null ],
    [ "Create", "classpdftron_1_1_p_d_f_1_1_file_spec.html#a36b0b9d2b42eb1e81878db818c69d7b1", null ],
    [ "CreateURL", "classpdftron_1_1_p_d_f_1_1_file_spec.html#a8342c9913cc1344aa55bd2ad79f3c80d", null ],
    [ "Export", "classpdftron_1_1_p_d_f_1_1_file_spec.html#ad8f3788f3a524610f11f0ca64eccb7d4", null ],
    [ "GetFileData", "classpdftron_1_1_p_d_f_1_1_file_spec.html#a4670f48ced2e55db5c3334c03d448b27", null ],
    [ "GetFilePath", "classpdftron_1_1_p_d_f_1_1_file_spec.html#aff55795b60fe5abab7f63f714e8e67ea", null ],
    [ "GetSDFObj", "classpdftron_1_1_p_d_f_1_1_file_spec.html#a9cc1d4fbfbcad573987efe8bcfc05592", null ],
    [ "IsValid", "classpdftron_1_1_p_d_f_1_1_file_spec.html#a8a4cb8f49723cb4a59c7a1bedded6b27", null ],
    [ "operator=", "classpdftron_1_1_p_d_f_1_1_file_spec.html#ab44d568b4de5ed1768c53db4702f1e44", null ],
    [ "operator==", "classpdftron_1_1_p_d_f_1_1_file_spec.html#a22e256c04e557cf8ed897e11a099c735", null ],
    [ "SetDesc", "classpdftron_1_1_p_d_f_1_1_file_spec.html#aa79ac3ffd11b1e2416c9753b54dc198a", null ]
];