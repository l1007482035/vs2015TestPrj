var classpdftron_1_1_p_d_f_1_1_job_request =
[
    [ "ProcHandler", "classpdftron_1_1_p_d_f_1_1_job_request.html#a23317a213a7b4c9f86af32d1300e43c9", null ],
    [ "ResultState", "classpdftron_1_1_p_d_f_1_1_job_request.html#ad2f96225c557fe2b0fec26e2b0fdc839", [
      [ "e_failure", "classpdftron_1_1_p_d_f_1_1_job_request.html#ad2f96225c557fe2b0fec26e2b0fdc839acfda764884e2e3d4ef9f56e677f395b2", null ],
      [ "e_success", "classpdftron_1_1_p_d_f_1_1_job_request.html#ad2f96225c557fe2b0fec26e2b0fdc839ad79245b713730f821ebdb92a025570da", null ],
      [ "e_security_error", "classpdftron_1_1_p_d_f_1_1_job_request.html#ad2f96225c557fe2b0fec26e2b0fdc839ac8d94904ed049ca393b206e548617f80", null ],
      [ "e_cancel", "classpdftron_1_1_p_d_f_1_1_job_request.html#ad2f96225c557fe2b0fec26e2b0fdc839abeaf76e49efdff328906f3fe9f09dd4b", null ],
      [ "e_package_error", "classpdftron_1_1_p_d_f_1_1_job_request.html#ad2f96225c557fe2b0fec26e2b0fdc839aa9c5afbd3a8b323e3b228aa65d2bee43", null ],
      [ "e_previous_crash", "classpdftron_1_1_p_d_f_1_1_job_request.html#ad2f96225c557fe2b0fec26e2b0fdc839a7abf5fd0e7412f04ac6f53016ae9d095", null ],
      [ "e_not_found", "classpdftron_1_1_p_d_f_1_1_job_request.html#ad2f96225c557fe2b0fec26e2b0fdc839ada98eb59e8ffb91b0a6c839b878371ab", null ],
      [ "e_fetch", "classpdftron_1_1_p_d_f_1_1_job_request.html#ad2f96225c557fe2b0fec26e2b0fdc839ade29ea3959cc0f6d146f0bb9d0687680", null ],
      [ "e_render", "classpdftron_1_1_p_d_f_1_1_job_request.html#ad2f96225c557fe2b0fec26e2b0fdc839a15ee27a75067823061a3517f3c0a61c9", null ],
      [ "e_postponed", "classpdftron_1_1_p_d_f_1_1_job_request.html#ad2f96225c557fe2b0fec26e2b0fdc839ab78a5b8b9d945f3e6bcbfd2aa4a3431a", null ]
    ] ]
];