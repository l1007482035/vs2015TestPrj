var classpdftron_1_1_p_d_f_1_1_image_settings =
[
    [ "CompressionMode", "classpdftron_1_1_p_d_f_1_1_image_settings.html#abf94aa1d5075b3207b1097e1ff275ce7", [
      [ "e_retain", "classpdftron_1_1_p_d_f_1_1_image_settings.html#abf94aa1d5075b3207b1097e1ff275ce7a31a4f17652329f39dbce3d2a4362f5ae", null ],
      [ "e_flate", "classpdftron_1_1_p_d_f_1_1_image_settings.html#abf94aa1d5075b3207b1097e1ff275ce7a55b1e5b36cf94708f2622e3eb2fbc136", null ],
      [ "e_jpeg", "classpdftron_1_1_p_d_f_1_1_image_settings.html#abf94aa1d5075b3207b1097e1ff275ce7a1285c5e7713162e50455edf7520c46df", null ],
      [ "e_jpeg2000", "classpdftron_1_1_p_d_f_1_1_image_settings.html#abf94aa1d5075b3207b1097e1ff275ce7a8792f9963ccdd0fefcdfc9d0d622e2ad", null ],
      [ "e_none", "classpdftron_1_1_p_d_f_1_1_image_settings.html#abf94aa1d5075b3207b1097e1ff275ce7add5da9ae8a6dc5c49034c323333e1371", null ]
    ] ],
    [ "DownsampleMode", "classpdftron_1_1_p_d_f_1_1_image_settings.html#a2939d819d4c249d88afc9dfe7d160fdd", [
      [ "e_off", "classpdftron_1_1_p_d_f_1_1_image_settings.html#a2939d819d4c249d88afc9dfe7d160fdda621208bdbcd398a7be84a1d915e03f5f", null ],
      [ "e_default", "classpdftron_1_1_p_d_f_1_1_image_settings.html#a2939d819d4c249d88afc9dfe7d160fddaa1ebbc47d4c87ff9361fda732260204e", null ]
    ] ],
    [ "ImageSettings", "classpdftron_1_1_p_d_f_1_1_image_settings.html#ab14ebff5988c171cf233cd914310390d", null ],
    [ "ForceChanges", "classpdftron_1_1_p_d_f_1_1_image_settings.html#afbf665ba35d85a73789f15b168675668", null ],
    [ "ForceRecompression", "classpdftron_1_1_p_d_f_1_1_image_settings.html#a2e4adb38e008311a4b4b7175a5c9f9b9", null ],
    [ "SetCompressionMode", "classpdftron_1_1_p_d_f_1_1_image_settings.html#a40669e2b43fda559a12a7368a903c451", null ],
    [ "SetDownsampleMode", "classpdftron_1_1_p_d_f_1_1_image_settings.html#ab623a7491a7d3d97372b417bfa07746a", null ],
    [ "SetImageDPI", "classpdftron_1_1_p_d_f_1_1_image_settings.html#a1cce5177c61732444b2c0dd776cfe90a", null ],
    [ "SetQuality", "classpdftron_1_1_p_d_f_1_1_image_settings.html#a91f99d9b3f4ed47cce33774b3d8b66cb", null ]
];