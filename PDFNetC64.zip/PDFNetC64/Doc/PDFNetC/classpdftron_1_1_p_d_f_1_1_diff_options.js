var classpdftron_1_1_p_d_f_1_1_diff_options =
[
    [ "DiffOptions", "classpdftron_1_1_p_d_f_1_1_diff_options.html#af7658a10046baf7d768be1d38d532b27", null ],
    [ "~DiffOptions", "classpdftron_1_1_p_d_f_1_1_diff_options.html#acb28d308279191de4572fffeb1f0b83c", null ],
    [ "GetAddGroupAnnots", "classpdftron_1_1_p_d_f_1_1_diff_options.html#a486950c8947cce80741c720a3280cdfc", null ],
    [ "GetBlendMode", "classpdftron_1_1_p_d_f_1_1_diff_options.html#a9eba1fe418ac069ce561350e7ee279b9", null ],
    [ "GetColorA", "classpdftron_1_1_p_d_f_1_1_diff_options.html#aa0907bba95b011a9c96715d366f7a407", null ],
    [ "GetColorB", "classpdftron_1_1_p_d_f_1_1_diff_options.html#a2a0bbc6e5d02b5fe26b94900f14172e3", null ],
    [ "SetAddGroupAnnots", "classpdftron_1_1_p_d_f_1_1_diff_options.html#a9c3d7037a06db1f3fecb6adaf81e272c", null ],
    [ "SetBlendMode", "classpdftron_1_1_p_d_f_1_1_diff_options.html#a1caeb6f8e83fb824a9b192583f413d1a", null ],
    [ "SetColorA", "classpdftron_1_1_p_d_f_1_1_diff_options.html#a632c1bc6e9ac20fb7b6e13afb35b5a14", null ],
    [ "SetColorB", "classpdftron_1_1_p_d_f_1_1_diff_options.html#a1a95510052634d8380ac106cbd1cfe6d", null ]
];