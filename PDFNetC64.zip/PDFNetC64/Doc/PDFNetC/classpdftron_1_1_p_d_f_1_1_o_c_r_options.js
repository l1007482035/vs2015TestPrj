var classpdftron_1_1_p_d_f_1_1_o_c_r_options =
[
    [ "OCROptions", "classpdftron_1_1_p_d_f_1_1_o_c_r_options.html#a3597056eb8d70915040ae06431e52567", null ],
    [ "~OCROptions", "classpdftron_1_1_p_d_f_1_1_o_c_r_options.html#a6a67139fb192dde550d5c0204087d31e", null ],
    [ "AddDPI", "classpdftron_1_1_p_d_f_1_1_o_c_r_options.html#a57a4af8c90f0542a4a69d2feccee8bc1", null ],
    [ "AddIgnoreZonesForPage", "classpdftron_1_1_p_d_f_1_1_o_c_r_options.html#a221966ef59effe5a5aa7634da69cadd3", null ],
    [ "AddLang", "classpdftron_1_1_p_d_f_1_1_o_c_r_options.html#a56d51b8a3acde9a6b05a3f007949c6a7", null ],
    [ "AddTextZonesForPage", "classpdftron_1_1_p_d_f_1_1_o_c_r_options.html#a058057cdc8eead7aa39ae59769c93f36", null ],
    [ "SetUsePDFPageCoords", "classpdftron_1_1_p_d_f_1_1_o_c_r_options.html#a47e16f28e63f9807d350e7c0f22105a6", null ]
];