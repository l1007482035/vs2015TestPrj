var classpdftron_1_1_p_d_f_1_1_content_replacer =
[
    [ "ContentReplacer", "classpdftron_1_1_p_d_f_1_1_content_replacer.html#ae8ab4a434f5322c6a8274b12eee49650", null ],
    [ "~ContentReplacer", "classpdftron_1_1_p_d_f_1_1_content_replacer.html#ad8e7e6d107bca10ac056a7c0502910f3", null ],
    [ "AddImage", "classpdftron_1_1_p_d_f_1_1_content_replacer.html#a5505d35197a0493faaac86d6c4e756a2", null ],
    [ "AddString", "classpdftron_1_1_p_d_f_1_1_content_replacer.html#ae9d643ddb35338d9c7b8830abc8da833", null ],
    [ "AddText", "classpdftron_1_1_p_d_f_1_1_content_replacer.html#a4fdea1ac1768cb88f77fad765a96872f", null ],
    [ "Destroy", "classpdftron_1_1_p_d_f_1_1_content_replacer.html#a9216e6148eb078ffae157fa8702d965a", null ],
    [ "Process", "classpdftron_1_1_p_d_f_1_1_content_replacer.html#a88960cd241c58f24f38304ebffc2862d", null ],
    [ "SetMatchStrings", "classpdftron_1_1_p_d_f_1_1_content_replacer.html#afdf77eb93855bfc81420bf98f2a8fc2b", null ],
    [ "mp_impl", "classpdftron_1_1_p_d_f_1_1_content_replacer.html#ad8cb33ba5b1bebbf315c1a26f10e69ae", null ]
];