var classpdftron_1_1_p_d_f_1_1_shaped_text =
[
    [ "FailureReason", "classpdftron_1_1_p_d_f_1_1_shaped_text.html#a1b30e38126d69d69acd971b107cf5cde", [
      [ "e_NoFailure", "classpdftron_1_1_p_d_f_1_1_shaped_text.html#a1b30e38126d69d69acd971b107cf5cdea1d4786ece52b21127bf6cee95dc2b715", null ],
      [ "e_UnsupportedFontType", "classpdftron_1_1_p_d_f_1_1_shaped_text.html#a1b30e38126d69d69acd971b107cf5cdeaad7b92434a5703c1935aef24dcb22aed", null ],
      [ "e_NotIndexEncoded", "classpdftron_1_1_p_d_f_1_1_shaped_text.html#a1b30e38126d69d69acd971b107cf5cdeabc2dd035ff187e1ec96bf014aaf9dca6", null ],
      [ "e_FontDataNotFound", "classpdftron_1_1_p_d_f_1_1_shaped_text.html#a1b30e38126d69d69acd971b107cf5cdeac3fdab8204d41034cdfc125c344e9d4e", null ]
    ] ],
    [ "ShapingStatus", "classpdftron_1_1_p_d_f_1_1_shaped_text.html#ab4ae4007ba8eecf5be850b95dcfe3f22", [
      [ "e_FullShaping", "classpdftron_1_1_p_d_f_1_1_shaped_text.html#ab4ae4007ba8eecf5be850b95dcfe3f22ad467c1e509c165166c0aa12687ed1d02", null ],
      [ "e_PartialShaping", "classpdftron_1_1_p_d_f_1_1_shaped_text.html#ab4ae4007ba8eecf5be850b95dcfe3f22a2941dc53bb81352b829df63342f41eba", null ],
      [ "e_NoShaping", "classpdftron_1_1_p_d_f_1_1_shaped_text.html#ab4ae4007ba8eecf5be850b95dcfe3f22abedc91c3257f86d02111f545edca639e", null ]
    ] ],
    [ "ShapedText", "classpdftron_1_1_p_d_f_1_1_shaped_text.html#a11a721e8ef9d855781cd6188eb0aee6a", null ],
    [ "ShapedText", "classpdftron_1_1_p_d_f_1_1_shaped_text.html#aef34411028c5987c9e6af97662bfbe31", null ],
    [ "ShapedText", "classpdftron_1_1_p_d_f_1_1_shaped_text.html#a432b6fa56d47d41b78cd69e30ef34111", null ],
    [ "~ShapedText", "classpdftron_1_1_p_d_f_1_1_shaped_text.html#a1f93be5ba6b8cab9b6a4e26dc4251dc8", null ],
    [ "Destroy", "classpdftron_1_1_p_d_f_1_1_shaped_text.html#ab6dcb6b9fc9fd72578cbf67136211c0a", null ],
    [ "GetFailureReason", "classpdftron_1_1_p_d_f_1_1_shaped_text.html#a2c43780cbd65b36f77e5e5cfcbe71c14", null ],
    [ "GetGlyph", "classpdftron_1_1_p_d_f_1_1_shaped_text.html#a704f1104c1a4fcd406e82eb3f5dc55cd", null ],
    [ "GetGlyphXPos", "classpdftron_1_1_p_d_f_1_1_shaped_text.html#a776697d2ecd4a08109ff4c20ddb26104", null ],
    [ "GetGlyphYPos", "classpdftron_1_1_p_d_f_1_1_shaped_text.html#a4319783a71c5b8a51f654c114b964494", null ],
    [ "GetNumGlyphs", "classpdftron_1_1_p_d_f_1_1_shaped_text.html#a346976e63fd1a48b2849e83ab69e5cb2", null ],
    [ "GetScale", "classpdftron_1_1_p_d_f_1_1_shaped_text.html#adac63a12db30f89264c540c858b0cef5", null ],
    [ "GetShapingStatus", "classpdftron_1_1_p_d_f_1_1_shaped_text.html#ab29a689ae37ef87a5288d1c172724e5e", null ],
    [ "GetText", "classpdftron_1_1_p_d_f_1_1_shaped_text.html#ab9d725989c7d71867bf460c9362683e3", null ],
    [ "operator=", "classpdftron_1_1_p_d_f_1_1_shaped_text.html#aedaab611833f0375bb7f6bbc6d350e78", null ],
    [ "m_impl", "classpdftron_1_1_p_d_f_1_1_shaped_text.html#adb692456e33c4b69b26e0bb7bf6a2858", null ]
];