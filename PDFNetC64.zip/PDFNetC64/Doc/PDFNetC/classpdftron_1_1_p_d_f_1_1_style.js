var classpdftron_1_1_p_d_f_1_1_style =
[
    [ "Style", "classpdftron_1_1_p_d_f_1_1_style.html#a8ff0723a4ef45deaa20995cdfbf23f10", null ],
    [ "GetColor", "classpdftron_1_1_p_d_f_1_1_style.html#a64bb31b2360d3af5e256de2240fb8ece", null ],
    [ "GetColor", "classpdftron_1_1_p_d_f_1_1_style.html#a795d88b827b59d5d608b22a073f07ab2", null ],
    [ "GetFont", "classpdftron_1_1_p_d_f_1_1_style.html#ac4a9307e8b7908edd67546971274f796", null ],
    [ "GetFontName", "classpdftron_1_1_p_d_f_1_1_style.html#a904300209e7e58a90d3c48c6dd00cfa7", null ],
    [ "GetFontSize", "classpdftron_1_1_p_d_f_1_1_style.html#ade921bd27e37c917e4c1fbffaeb303a5", null ],
    [ "GetWeight", "classpdftron_1_1_p_d_f_1_1_style.html#ae34ca1cf5644b8b5b863863ab2b34483", null ],
    [ "IsItalic", "classpdftron_1_1_p_d_f_1_1_style.html#abcdc773dae9994adbcf4ac1252ca3b8c", null ],
    [ "IsSerif", "classpdftron_1_1_p_d_f_1_1_style.html#ae36086d220feb1cb92fe21e36c2c0757", null ],
    [ "operator!=", "classpdftron_1_1_p_d_f_1_1_style.html#abc21b6411b9273e12c2556ce2085a04c", null ],
    [ "operator==", "classpdftron_1_1_p_d_f_1_1_style.html#a73c339f75a8702411b0ee569b34e63aa", null ]
];