var classpdftron_1_1_p_d_f_1_1_key_stroke_action_result =
[
    [ "~KeyStrokeActionResult", "classpdftron_1_1_p_d_f_1_1_key_stroke_action_result.html#ae68ff8287c2ecdccd1603de07f4c9e21", null ],
    [ "KeyStrokeActionResult", "classpdftron_1_1_p_d_f_1_1_key_stroke_action_result.html#a9d463f0bf47e829a18ef8c92dac13504", null ],
    [ "KeyStrokeActionResult", "classpdftron_1_1_p_d_f_1_1_key_stroke_action_result.html#aaaeda3a29418ecc315edc503be1fdb3d", null ],
    [ "KeyStrokeActionResult", "classpdftron_1_1_p_d_f_1_1_key_stroke_action_result.html#a369d51e4b61ab4849d3b4b64402ca221", null ],
    [ "Destroy", "classpdftron_1_1_p_d_f_1_1_key_stroke_action_result.html#a1ec8c0565ff73bc8feb751da38bc837c", null ],
    [ "GetText", "classpdftron_1_1_p_d_f_1_1_key_stroke_action_result.html#a1d143a1db65a03ef04d0f955ac9e3209", null ],
    [ "IsValid", "classpdftron_1_1_p_d_f_1_1_key_stroke_action_result.html#a30250bb841f177496b775a9f59333d96", null ],
    [ "operator=", "classpdftron_1_1_p_d_f_1_1_key_stroke_action_result.html#a82d213e4fc3b81674444369d61050cf3", null ],
    [ "mp_result", "classpdftron_1_1_p_d_f_1_1_key_stroke_action_result.html#a2a7d89a492c70b92c3fe03d0681066d7", null ]
];