var classpdftron_1_1_p_d_f_1_1_proxy =
[
    [ "Type", "classpdftron_1_1_p_d_f_1_1_proxy.html#af54bdaf82ba1828fdd104ba832114160", [
      [ "e_default", "classpdftron_1_1_p_d_f_1_1_proxy.html#af54bdaf82ba1828fdd104ba832114160a6e7ae288d2f90e8be3b39a2ae3742b42", null ],
      [ "e_none", "classpdftron_1_1_p_d_f_1_1_proxy.html#af54bdaf82ba1828fdd104ba832114160a0cf34c8ac1ee0dd42cb3f3e7a833d04b", null ],
      [ "e_http", "classpdftron_1_1_p_d_f_1_1_proxy.html#af54bdaf82ba1828fdd104ba832114160a7b3ec19e54a33eafd7994dca1b2fdff5", null ],
      [ "e_socks5", "classpdftron_1_1_p_d_f_1_1_proxy.html#af54bdaf82ba1828fdd104ba832114160a425255e55669f734b12b46cee29e65c3", null ]
    ] ],
    [ "Proxy", "classpdftron_1_1_p_d_f_1_1_proxy.html#a1042d1fdaafd27d18e0619749ccff3d9", null ],
    [ "~Proxy", "classpdftron_1_1_p_d_f_1_1_proxy.html#add058b984f0b815adb1fd2757bfc025d", null ],
    [ "Destroy", "classpdftron_1_1_p_d_f_1_1_proxy.html#ab2c422d638056f07084b491a548b7f58", null ],
    [ "SetHost", "classpdftron_1_1_p_d_f_1_1_proxy.html#a444c0595842a7f639e537e69a74e8371", null ],
    [ "SetPassword", "classpdftron_1_1_p_d_f_1_1_proxy.html#ac3f49765b88c7f17d3120c89a1d53f7e", null ],
    [ "SetPort", "classpdftron_1_1_p_d_f_1_1_proxy.html#a6fdc8d76efabacd6080d6c26ca64cc47", null ],
    [ "SetType", "classpdftron_1_1_p_d_f_1_1_proxy.html#a48e35c25fde4c395a60c556b8d806b25", null ],
    [ "SetUsername", "classpdftron_1_1_p_d_f_1_1_proxy.html#a6962b2a3824ce773c36553d84a532bc6", null ]
];