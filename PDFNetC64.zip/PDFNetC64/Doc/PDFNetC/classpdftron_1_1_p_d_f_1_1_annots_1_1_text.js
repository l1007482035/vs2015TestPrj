var classpdftron_1_1_p_d_f_1_1_annots_1_1_text =
[
    [ "Icon", "classpdftron_1_1_p_d_f_1_1_annots_1_1_text.html#afb4fa207369167dce071f7dd2434eddc", [
      [ "e_Comment", "classpdftron_1_1_p_d_f_1_1_annots_1_1_text.html#afb4fa207369167dce071f7dd2434eddca1045766c39f87aedd5d0a3755f773d74", null ],
      [ "e_Key", "classpdftron_1_1_p_d_f_1_1_annots_1_1_text.html#afb4fa207369167dce071f7dd2434eddcae58b2a4bfda8f771cd59953c9b9a1f02", null ],
      [ "e_Help", "classpdftron_1_1_p_d_f_1_1_annots_1_1_text.html#afb4fa207369167dce071f7dd2434eddca2784de842fb3317e6d3ecbc6c87b7f71", null ],
      [ "e_NewParagraph", "classpdftron_1_1_p_d_f_1_1_annots_1_1_text.html#afb4fa207369167dce071f7dd2434eddca38ab1e047dbe6725cf50a942a43fcb7a", null ],
      [ "e_Paragraph", "classpdftron_1_1_p_d_f_1_1_annots_1_1_text.html#afb4fa207369167dce071f7dd2434eddca45256d7f66585c3622573eb6ba4d1e3a", null ],
      [ "e_Insert", "classpdftron_1_1_p_d_f_1_1_annots_1_1_text.html#afb4fa207369167dce071f7dd2434eddca5500c83287e427bfb5c7c756e76aa9d3", null ],
      [ "e_Note", "classpdftron_1_1_p_d_f_1_1_annots_1_1_text.html#afb4fa207369167dce071f7dd2434eddcaea037597a698845125e8c4ab29e10987", null ],
      [ "e_Unknown", "classpdftron_1_1_p_d_f_1_1_annots_1_1_text.html#afb4fa207369167dce071f7dd2434eddcae42cbaad2e0e378c13d3243bcb82d1a3", null ]
    ] ],
    [ "Text", "classpdftron_1_1_p_d_f_1_1_annots_1_1_text.html#a95c5ba72a95f7257979f9194a14815a2", null ],
    [ "Text", "classpdftron_1_1_p_d_f_1_1_annots_1_1_text.html#a3f7205e3b6fdbb45c8bddc2e994a732f", null ],
    [ "Create", "classpdftron_1_1_p_d_f_1_1_annots_1_1_text.html#ad16c7e82892f00fd1eca6126bbb78377", null ],
    [ "Create", "classpdftron_1_1_p_d_f_1_1_annots_1_1_text.html#a5c22f8be0feec2be1fc792b7624b4645", null ],
    [ "GetIcon", "classpdftron_1_1_p_d_f_1_1_annots_1_1_text.html#a0e81de5671f0c62a999f42238ad41906", null ],
    [ "GetIconName", "classpdftron_1_1_p_d_f_1_1_annots_1_1_text.html#a68c043101989d6615f6ccc995ea7c90c", null ],
    [ "GetState", "classpdftron_1_1_p_d_f_1_1_annots_1_1_text.html#a2487ca6959f80807ff62495e6a2d2a27", null ],
    [ "GetStateModel", "classpdftron_1_1_p_d_f_1_1_annots_1_1_text.html#a3c7d22bb0f6003109ef84dd59c8e6b4a", null ],
    [ "IsOpen", "classpdftron_1_1_p_d_f_1_1_annots_1_1_text.html#a79c233f6bb9603e702ad17668a4faa90", null ],
    [ "SetIcon", "classpdftron_1_1_p_d_f_1_1_annots_1_1_text.html#a5b2b2a9d366dd6911966e01d305a9225", null ],
    [ "SetIcon", "classpdftron_1_1_p_d_f_1_1_annots_1_1_text.html#a791a80b0e2b1ab4f19fe2d7a136bf553", null ],
    [ "SetOpen", "classpdftron_1_1_p_d_f_1_1_annots_1_1_text.html#ad6daa53d261b3b38baba68e460c485cd", null ],
    [ "SetState", "classpdftron_1_1_p_d_f_1_1_annots_1_1_text.html#a5f9437d70892d36682465dfd15f14fab", null ],
    [ "SetStateModel", "classpdftron_1_1_p_d_f_1_1_annots_1_1_text.html#ac9158af88afda24a8f222b6f29450d39", null ]
];