var classpdftron_1_1_p_d_f_1_1_annots_1_1_squiggly =
[
    [ "Squiggly", "classpdftron_1_1_p_d_f_1_1_annots_1_1_squiggly.html#aa8e4ae67343f341f98d81efedd300d77", null ],
    [ "Squiggly", "classpdftron_1_1_p_d_f_1_1_annots_1_1_squiggly.html#ad50eda30c87fb62fe54fcf79b776a14f", null ],
    [ "Create", "classpdftron_1_1_p_d_f_1_1_annots_1_1_squiggly.html#a86c3407d7bc47fecf5577bb0428a54d6", null ]
];