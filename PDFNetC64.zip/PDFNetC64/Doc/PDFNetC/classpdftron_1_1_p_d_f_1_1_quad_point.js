var classpdftron_1_1_p_d_f_1_1_quad_point =
[
    [ "QuadPoint", "classpdftron_1_1_p_d_f_1_1_quad_point.html#a5246d73b5334bab241a0c29e8b4d30c6", null ],
    [ "QuadPoint", "classpdftron_1_1_p_d_f_1_1_quad_point.html#a438a10a13fd497b07065e63688af7237", null ],
    [ "QuadPoint", "classpdftron_1_1_p_d_f_1_1_quad_point.html#a33b40f191aa66a9dbea4b7f45f45b11b", null ],
    [ "p1", "classpdftron_1_1_p_d_f_1_1_quad_point.html#ac50959082f488fd01d8b9b2999ae86aa", null ],
    [ "p2", "classpdftron_1_1_p_d_f_1_1_quad_point.html#ae5e1f5b2132489294ced9df4c02b82a6", null ],
    [ "p3", "classpdftron_1_1_p_d_f_1_1_quad_point.html#a35ec447131dc6ebce83d0e2e941966a1", null ],
    [ "p4", "classpdftron_1_1_p_d_f_1_1_quad_point.html#a3a39d2c9cb01872c4ccef1f41e41b82e", null ]
];