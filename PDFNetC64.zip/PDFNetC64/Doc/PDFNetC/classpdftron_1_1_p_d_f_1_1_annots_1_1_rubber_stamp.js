var classpdftron_1_1_p_d_f_1_1_annots_1_1_rubber_stamp =
[
    [ "Icon", "classpdftron_1_1_p_d_f_1_1_annots_1_1_rubber_stamp.html#a48a419d014aa70469d2377645d94872b", [
      [ "e_Approved", "classpdftron_1_1_p_d_f_1_1_annots_1_1_rubber_stamp.html#a48a419d014aa70469d2377645d94872baf599d3533e71c9f8df3a57a46641f6a1", null ],
      [ "e_Experimental", "classpdftron_1_1_p_d_f_1_1_annots_1_1_rubber_stamp.html#a48a419d014aa70469d2377645d94872ba29adec50ba29f285ee0d656f99bf199f", null ],
      [ "e_NotApproved", "classpdftron_1_1_p_d_f_1_1_annots_1_1_rubber_stamp.html#a48a419d014aa70469d2377645d94872ba6d9e7f62a17dd35bb0886e7eda36ac01", null ],
      [ "e_AsIs", "classpdftron_1_1_p_d_f_1_1_annots_1_1_rubber_stamp.html#a48a419d014aa70469d2377645d94872ba68730c4128be993faeffdf5b3bd60e6a", null ],
      [ "e_Expired", "classpdftron_1_1_p_d_f_1_1_annots_1_1_rubber_stamp.html#a48a419d014aa70469d2377645d94872ba7ce18fc40ed8dd4159792540a3bbe254", null ],
      [ "e_NotForPublicRelease", "classpdftron_1_1_p_d_f_1_1_annots_1_1_rubber_stamp.html#a48a419d014aa70469d2377645d94872ba341ae0a37296f2751321b9f4a6c7bc53", null ],
      [ "e_Confidential", "classpdftron_1_1_p_d_f_1_1_annots_1_1_rubber_stamp.html#a48a419d014aa70469d2377645d94872ba5a558b2d939914c27883c3f7ab69c283", null ],
      [ "e_Final", "classpdftron_1_1_p_d_f_1_1_annots_1_1_rubber_stamp.html#a48a419d014aa70469d2377645d94872ba9f236164f6cc0d158d173542e50faa4f", null ],
      [ "e_Sold", "classpdftron_1_1_p_d_f_1_1_annots_1_1_rubber_stamp.html#a48a419d014aa70469d2377645d94872ba954285bb6d8d2114d757ae5f090732b4", null ],
      [ "e_Departmental", "classpdftron_1_1_p_d_f_1_1_annots_1_1_rubber_stamp.html#a48a419d014aa70469d2377645d94872ba92eefd3aae2541065ae1a5d56d4a1dfd", null ],
      [ "e_ForComment", "classpdftron_1_1_p_d_f_1_1_annots_1_1_rubber_stamp.html#a48a419d014aa70469d2377645d94872bab9ca578bd094d3dc6dc5e8b177fd68ac", null ],
      [ "e_TopSecret", "classpdftron_1_1_p_d_f_1_1_annots_1_1_rubber_stamp.html#a48a419d014aa70469d2377645d94872ba6eea82aff9d002e43a6b7e1b00dd0217", null ],
      [ "e_ForPublicRelease", "classpdftron_1_1_p_d_f_1_1_annots_1_1_rubber_stamp.html#a48a419d014aa70469d2377645d94872ba0970ca84d75a1f434bed0417cef265bf", null ],
      [ "e_Draft", "classpdftron_1_1_p_d_f_1_1_annots_1_1_rubber_stamp.html#a48a419d014aa70469d2377645d94872ba3f0032008914f880e9b1b350cdee4d93", null ],
      [ "e_Unknown", "classpdftron_1_1_p_d_f_1_1_annots_1_1_rubber_stamp.html#a48a419d014aa70469d2377645d94872ba9f4d0507c4739982beb04a6c0e1cb21f", null ]
    ] ],
    [ "RubberStamp", "classpdftron_1_1_p_d_f_1_1_annots_1_1_rubber_stamp.html#aa05c4fba6fcde86a01d4304414103727", null ],
    [ "RubberStamp", "classpdftron_1_1_p_d_f_1_1_annots_1_1_rubber_stamp.html#aec2386836e48b79e7741985fc28eaad3", null ],
    [ "Create", "classpdftron_1_1_p_d_f_1_1_annots_1_1_rubber_stamp.html#a4bc2a32daf92133f89d388cefbeb57e4", null ],
    [ "Create", "classpdftron_1_1_p_d_f_1_1_annots_1_1_rubber_stamp.html#a065a2adaab9e4c4b705894f556e69f83", null ],
    [ "GetIcon", "classpdftron_1_1_p_d_f_1_1_annots_1_1_rubber_stamp.html#acdc16c8ac73b643de603ae8a4bf44497", null ],
    [ "GetIconName", "classpdftron_1_1_p_d_f_1_1_annots_1_1_rubber_stamp.html#a171dbdc5796553836e340f295dd05195", null ],
    [ "SetIcon", "classpdftron_1_1_p_d_f_1_1_annots_1_1_rubber_stamp.html#a6df4ea5c678b3b2191667f8bfa7c0371", null ],
    [ "SetIcon", "classpdftron_1_1_p_d_f_1_1_annots_1_1_rubber_stamp.html#a3068d388416c67f21471d771cc746e70", null ]
];