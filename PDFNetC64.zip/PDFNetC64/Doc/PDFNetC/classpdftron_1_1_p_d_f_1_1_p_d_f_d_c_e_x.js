var classpdftron_1_1_p_d_f_1_1_p_d_f_d_c_e_x =
[
    [ "PDFDCEX", "classpdftron_1_1_p_d_f_1_1_p_d_f_d_c_e_x.html#a26bba925c802273c3c6a672f4a6cd08a", null ],
    [ "~PDFDCEX", "classpdftron_1_1_p_d_f_1_1_p_d_f_d_c_e_x.html#a8e7d813b25f9c67731d92568c836c352", null ],
    [ "Begin", "classpdftron_1_1_p_d_f_1_1_p_d_f_d_c_e_x.html#a0681b330a57338e8a182315d0bac5d0f", null ],
    [ "Destroy", "classpdftron_1_1_p_d_f_1_1_p_d_f_d_c_e_x.html#a0befc4da34a53e36ae3ec04647506fcb", null ],
    [ "End", "classpdftron_1_1_p_d_f_1_1_p_d_f_d_c_e_x.html#a614504760d0f296f382c3e1d8902feb6", null ],
    [ "GetDPI", "classpdftron_1_1_p_d_f_1_1_p_d_f_d_c_e_x.html#aea005a1e55121c22deac0dd9104bfb24", null ]
];