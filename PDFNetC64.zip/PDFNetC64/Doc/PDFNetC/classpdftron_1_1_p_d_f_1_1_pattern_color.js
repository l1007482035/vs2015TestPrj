var classpdftron_1_1_p_d_f_1_1_pattern_color =
[
    [ "TilingType", "classpdftron_1_1_p_d_f_1_1_pattern_color.html#a10fe1604e14c62ef75e1e0c78d9d3821", [
      [ "e_constant_spacing", "classpdftron_1_1_p_d_f_1_1_pattern_color.html#a10fe1604e14c62ef75e1e0c78d9d3821afd324217af2f3bf18ecb7fd4ba4d93f3", null ],
      [ "e_no_distortion", "classpdftron_1_1_p_d_f_1_1_pattern_color.html#a10fe1604e14c62ef75e1e0c78d9d3821a515958b605d73cb040216be513a81a13", null ],
      [ "e_constant_spacing_fast_fill", "classpdftron_1_1_p_d_f_1_1_pattern_color.html#a10fe1604e14c62ef75e1e0c78d9d3821aeeb80fbd1cabe5d0943a3bef587bed22", null ]
    ] ],
    [ "Type", "classpdftron_1_1_p_d_f_1_1_pattern_color.html#a450bc4a12e8d8488c2ccbfa8a0a1fb2d", [
      [ "e_uncolored_tiling_pattern", "classpdftron_1_1_p_d_f_1_1_pattern_color.html#a450bc4a12e8d8488c2ccbfa8a0a1fb2da160535e20d630d1903f3345d4baf3816", null ],
      [ "e_colored_tiling_pattern", "classpdftron_1_1_p_d_f_1_1_pattern_color.html#a450bc4a12e8d8488c2ccbfa8a0a1fb2da925c8132dc358eee9ca9d2a4a74c188b", null ],
      [ "e_shading", "classpdftron_1_1_p_d_f_1_1_pattern_color.html#a450bc4a12e8d8488c2ccbfa8a0a1fb2da8e61413cd824c4354aafbfd71b7b7a53", null ],
      [ "e_null", "classpdftron_1_1_p_d_f_1_1_pattern_color.html#a450bc4a12e8d8488c2ccbfa8a0a1fb2dae9a8ebab75c33539dffc85c493f0564c", null ]
    ] ],
    [ "PatternColor", "classpdftron_1_1_p_d_f_1_1_pattern_color.html#a14d222ef6eb79ceeddd3a7fadcf067a1", null ],
    [ "PatternColor", "classpdftron_1_1_p_d_f_1_1_pattern_color.html#a49ec519ef9065d3e1cc85abc6136b1ae", null ],
    [ "~PatternColor", "classpdftron_1_1_p_d_f_1_1_pattern_color.html#a7b26e01ff32aee5154ebd1cd00d8c90e", null ],
    [ "Destroy", "classpdftron_1_1_p_d_f_1_1_pattern_color.html#a3229a35526bcf5c467e9d646b7888c6b", null ],
    [ "GetBBox", "classpdftron_1_1_p_d_f_1_1_pattern_color.html#a7f542a1523cde8b007d9bcf4c8741011", null ],
    [ "GetMatrix", "classpdftron_1_1_p_d_f_1_1_pattern_color.html#aa405e77f8a62107acf7807e6acb196c9", null ],
    [ "GetSDFObj", "classpdftron_1_1_p_d_f_1_1_pattern_color.html#ac6e01933ab79e283d3b95971887057cf", null ],
    [ "GetShading", "classpdftron_1_1_p_d_f_1_1_pattern_color.html#acf5d4ada85a8cc5eabf31db3686bafb0", null ],
    [ "GetTilingType", "classpdftron_1_1_p_d_f_1_1_pattern_color.html#a51293dc998f4df015c4ec1b3d68c239d", null ],
    [ "GetType", "classpdftron_1_1_p_d_f_1_1_pattern_color.html#afd7df0c2af3fef7f36aabda9673c0136", null ],
    [ "GetXStep", "classpdftron_1_1_p_d_f_1_1_pattern_color.html#abc51d28f55812adfc5f644832404f03b", null ],
    [ "GetYStep", "classpdftron_1_1_p_d_f_1_1_pattern_color.html#a7710729d65d97c483cb38125ef7c1a9b", null ],
    [ "operator=", "classpdftron_1_1_p_d_f_1_1_pattern_color.html#a871f615071fd8998e54df8cad56c7e83", null ]
];