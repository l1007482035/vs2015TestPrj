var classpdftron_1_1_p_d_f_1_1_o_c_g_1_1_context =
[
    [ "OCDrawMode", "classpdftron_1_1_p_d_f_1_1_o_c_g_1_1_context.html#a6969c08b4774a3bd22841ae9998b34b6", [
      [ "e_VisibleOC", "classpdftron_1_1_p_d_f_1_1_o_c_g_1_1_context.html#a6969c08b4774a3bd22841ae9998b34b6ab57e7313dcbf1e75b08ef9931a943796", null ],
      [ "e_AllOC", "classpdftron_1_1_p_d_f_1_1_o_c_g_1_1_context.html#a6969c08b4774a3bd22841ae9998b34b6a28166a03cb35aa5f4ba6239e279e5ea6", null ],
      [ "e_NoOC", "classpdftron_1_1_p_d_f_1_1_o_c_g_1_1_context.html#a6969c08b4774a3bd22841ae9998b34b6a06848523cc576920eb15d6928151d393", null ]
    ] ],
    [ "Context", "classpdftron_1_1_p_d_f_1_1_o_c_g_1_1_context.html#a1356f2ff5c605edd570136497089958d", null ],
    [ "Context", "classpdftron_1_1_p_d_f_1_1_o_c_g_1_1_context.html#a893ab6ed2d3a14757ad90b5074027b35", null ],
    [ "~Context", "classpdftron_1_1_p_d_f_1_1_o_c_g_1_1_context.html#aa24a54bf986fa36f74d23234229edbff", null ],
    [ "Context", "classpdftron_1_1_p_d_f_1_1_o_c_g_1_1_context.html#a258c55443b7dee494982c8dffd863c06", null ],
    [ "CreateInternal", "classpdftron_1_1_p_d_f_1_1_o_c_g_1_1_context.html#a4bdb3c54eb36772582f408f2d38b528d", null ],
    [ "Destroy", "classpdftron_1_1_p_d_f_1_1_o_c_g_1_1_context.html#ae3e420727a6cf4dc3263990348336dd2", null ],
    [ "GetHandleInternal", "classpdftron_1_1_p_d_f_1_1_o_c_g_1_1_context.html#a4396ae7931eebb07a12600a6ccfa3a5d", null ],
    [ "GetNonOCDrawing", "classpdftron_1_1_p_d_f_1_1_o_c_g_1_1_context.html#a0cf1e1286efa05074fdcee09aa2f63b5", null ],
    [ "GetOCMode", "classpdftron_1_1_p_d_f_1_1_o_c_g_1_1_context.html#a7ff0ddc11ecce63b9c8430bdc7715746", null ],
    [ "GetState", "classpdftron_1_1_p_d_f_1_1_o_c_g_1_1_context.html#a04ba74026276f01b5bb7d1df371bcd05", null ],
    [ "IsValid", "classpdftron_1_1_p_d_f_1_1_o_c_g_1_1_context.html#a1e1766db425e3d724fa5c55700e94ed5", null ],
    [ "operator=", "classpdftron_1_1_p_d_f_1_1_o_c_g_1_1_context.html#ad59d95d7014e04f5820a1f80d0aebe04", null ],
    [ "ResetStates", "classpdftron_1_1_p_d_f_1_1_o_c_g_1_1_context.html#a4b4bdda5adbdc739985d8ea3df2a44b2", null ],
    [ "SetNonOCDrawing", "classpdftron_1_1_p_d_f_1_1_o_c_g_1_1_context.html#ae275bd40600e0dac06ab440ac6bdf7f5", null ],
    [ "SetOCDrawMode", "classpdftron_1_1_p_d_f_1_1_o_c_g_1_1_context.html#a0d6e63af30319c8e150e73d1d87884cf", null ],
    [ "SetState", "classpdftron_1_1_p_d_f_1_1_o_c_g_1_1_context.html#a621aff2a3c4bb5a4fd9654cbe0674d9d", null ],
    [ "mp_obj", "classpdftron_1_1_p_d_f_1_1_o_c_g_1_1_context.html#adb10c44d5b10952239e7c4c14738c637", null ]
];