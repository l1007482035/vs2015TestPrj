#ifndef SIMPLEAMQPCLIENT_AMQPLIBRARYEXCEPTION_H
#define SIMPLEAMQPCLIENT_AMQPLIBRARYEXCEPTION_H
/*
 * ***** BEGIN LICENSE BLOCK *****
 * Version: MIT
 *
 * Copyright (c) 2014 Alan Antonuk
 *
 * Permission is hereby granted, free of charge, to any person
 * obtaining a copy of this software and associated documentation
 * files (the "Software"), to deal in the Software without
 * restriction, including without limitation the rights to use, copy,
 * modify, merge, publish, distribute, sublicense, and/or sell copies
 * of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be
 * included in all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
 * EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
 * MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
 * NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS
 * BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN
 * ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN
 * CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 * ***** END LICENSE BLOCK *****
 */

#include <stdexcept>
#include <string>

#include "SimpleAmqpClient/Util.h"

#ifdef _MSC_VER
#pragma warning(push)
#pragma warning(disable : 4251 4275)
#endif

/// @file SimpleAmqpClient/AmqpLibraryException.h
/// Defines SimpleAmqpClient::AmqpLibraryException

struct amqp_rpc_reply_t_;

namespace AmqpClient {

/**
 * Errors arising from incorrect usage of this library APIs
 */
class SIMPLEAMQPCLIENT_EXPORT AmqpLibraryException : public std::runtime_error {
 public:
  /**
   * Factory-construct with an error code
   */
  static AmqpLibraryException CreateException(int error_code);
  /**
   * Factory-construct with an error code and a string context
   */
  static AmqpLibraryException CreateException(int error_code,
                                              const std::string &context);

  /**
   * Error code getter
   */
  int ErrorCode() const { return m_errorCode; }

 protected:
  /** @cond INTERNAL */
  explicit AmqpLibraryException(const std::string &message,
                                int error_code) throw();
  /** @endcond@ */

 private:
  int m_errorCode;
};

}  // namespace AmqpClient

#ifdef _MSC_VER
#pragma warning(pop)
#endif

#endif  // SIMPLEAMQPCLIENT_AMQPLIBRARYEXCEPTION_H
